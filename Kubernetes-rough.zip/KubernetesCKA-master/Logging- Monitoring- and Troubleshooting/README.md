## Demo of heapster + Grafana  + InfluxDB

Try to execute `kubectl top pod` command prior deploying the Heapster.

```
$ kubectl top pod
Error from server (NotFound): the server could not find the requested resource (get services http:heapster:)
```

To Demontsrate Monitoring using the Hepaster, Graphana and InfluxDB, first clone the Git repository `kubernetes/heapster`
```
$ git clone https://github.com/kubernetes/heapster.git
```

To run the Heapster using InfluxDB execute following command. Fisrt Get in the `heapster` directory.
```
$ cd heapster/
```

Now Deploy the Graphana, InfluxDB and Heapster.
```
$ kubectl create -f deploy/kube-config/influxdb/deployment "monitoring-grafana" created
service "monitoring-grafana" created
serviceaccount "heapster" created
deployment "heapster" created
service "heapster" created
deployment "monitoring-influxdb" created
service "monitoring-influxdb" created

```
Set the RBAC ClusterRole binding.
```
$ kubectl create -f deploy/kube-config/rbac/heapster-rbac.yaml
clusterrolebinding "heapster" created
```

Get List of Pods. and verify that Heapster, Grafana and influxDB pods are up and running.
```
$ kubectl get pods --namespace=kube-system
NAME                                   READY     STATUS    RESTARTS   AGE
default-http-backend-l0h2z             1/1       Running   0          31m
heapster-603813915-8qdrb               1/1       Running   0          21m
kube-addon-manager-minikube            1/1       Running   0          39m
kube-dns-910330662-tckj6               3/3       Running   0          31m
kubernetes-dashboard-vhwr7             1/1       Running   0          31m
monitoring-grafana-2175968514-wlc7g    1/1       Running   0          21m
monitoring-influxdb-1957622127-mjpgc   1/1       Running   0          21m
nginx-ingress-controller-srmct         1/1       Running   0          31m
```
Now Open Your Minikube?kubernetes Dashboard and you will see your resource usage are shown there with Visualization.


## Get CPU/Memory stats for Pods
You can simply get the stat of CPU/Memory used by pods by using following command.
```
$ kubectl top pods --namespace=kube-system
NAME                                   CPU(cores)   MEMORY(bytes)   
default-http-backend-l0h2z             0m           1Mi             
nginx-ingress-controller-srmct         2m           47Mi            
kube-dns-910330662-tckj6               1m           21Mi            
monitoring-grafana-2175968514-wlc7g    0m           9Mi             
heapster-603813915-8qdrb               0m           20Mi            
monitoring-influxdb-1957622127-mjpgc   1m           17Mi            
kube-addon-manager-minikube            49m          2Mi             
kubernetes-dashboard-vhwr7             0m           19Mi  
```
This command shows the CPU/memory Stat of all the pods in `kube-system` namespace.

We can get CPU/Memory stat of individual pod
```
$ kubectl top pods rsvp-2550261549-dc5dh
NAME                    CPU(cores)   MEMORY(bytes)   
rsvp-2550261549-dc5dh   17m          36Mi    
```















