## Sample Job to run echo “Hello World”

Create Simple Job from following configuration file.
```
apiVersion: batch/v1
kind: Job
metadata:
  name: nginx
spec:
  template:
    metadata:
      name: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:1.9.1
        command: ["/bin/sh"]
        args: ["-c", "echo Hello World"]
      restartPolicy: Never
```

Deploy a job from above Yaml file.
```
$  kubectl create -f simplejob.yaml 
job "nginx" created
```

Get list of Jobs
```
$ kubectl get job
NAME      DESIRED   SUCCESSFUL   AGE
nginx     1         1            10s
```
Get the list of pod which are part of above Job.
```
$ kubectl get po --show-all
NAME          READY     STATUS      RESTARTS   AGE
nginx-wzb68   0/1       Completed   0          56s
```
Check the logs of abve pod you will see output of that job.
```
$ kubectl logs nginx-wzb68
Hello World
```

## Cron Job to run something at 10 PM everyday.

Create a cron job configuration from follwoing file.
```
apiVersion: batch/v2alpha1
kind: CronJob
metadata:
  name: cron-job-demo
spec:
  schedule: "0 22 * * *"
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: demo
            image: nginx:1.9.1
            command: ["/bin/sh"]
            args: ["-c", "Time is 10PM"]
          restartPolicy: OnFailure
```




Deploy the cron job.
```
$ kubectl create -f cronjob.yaml 
cronjob "cron-job-demo" created
```
Get list of Cron job

```
kubectl get cronjob
NAME            SCHEDULE     SUSPEND   ACTIVE    LAST-SCHEDULE
cron-job-demo   0 22 * * *   False     0         <none>

```
