


# MYSQL statefulset.
Create a Statefulset Of mysql.

#### Create ConfigMap required for mysql application deployments.
```
apiVersion: v1
kind: ConfigMap
metadata:
  name: mysql
  labels:
    app: mysql
data:
  master.cnf: |
    # Apply this config only on the master.
    [mysqld]
    log-bin
  slave.cnf: |
    # Apply this config only on slaves.
    [mysqld]
    super-read-only
```

Create configmap from above configuration file.
```
$ kubectl create -f configmap.yaml 
configmap "mysql" created
```

#### Create 2 services as shown in below configuration file.
```
apiVersion: v1
kind: Service
metadata:
  name: mysql
  labels:
    app: mysql
spec:
  ports:
  - name: mysql
    port: 3306
  clusterIP: None
  selector:
    app: mysql
---
apiVersion: v1
kind: Service
metadata:
  name: mysql-read
  labels:
    app: mysql
spec:
  ports:
  - name: mysql
    port: 3306
  selector:
    app: mysql
```

Deploy the service.
```
$ kubectl create -f service.yaml 
service "mysql" created
service "mysql-read" created
```
Get the list of the services.
```
$ kubectl get svc
NAME          CLUSTER-IP   EXTERNAL-IP   PORT(S)        AGE
kubernetes    10.0.0.1     <none>        443/TCP        4d
mysql         None         <none>        3306/TCP       51s
mysql-read    10.0.0.227   <none>        3306/TCP       51s
```
- First service named `mysql` is Headless Service. This Headless Service provides a home for the DNS entries that the StatefulSet controller creates for each Pod that’s part of the set. Because the Headless Service is named mysql, the Pods are accessible by resolving `<pod-name>`. mysql from within any other Pod in the same Kubernetes cluster and namespace

- Second service named `mysql-read` is normal service. with its own cluster IP that distributes connections across all MySQL Pods that report being Ready. The set of potential endpoints includes the MySQL master and all slaves.


#### Create mysql stateful set as shown in following configuration file.

```
apiVersion: apps/v1beta1
kind: StatefulSet
metadata:
  name: mysql
spec:
  serviceName: mysql
  replicas: 3
  template:
    metadata:
      labels:
        app: mysql
      annotations:
        pod.beta.kubernetes.io/init-containers: '[
          {
            "name": "init-mysql",
            "image": "mysql:5.7",
            "command": ["bash", "-c", "
              set -ex\n
              # Generate mysql server-id from pod ordinal index.\n
              [[ `hostname` =~ -([0-9]+)$ ]] || exit 1\n
              ordinal=${BASH_REMATCH[1]}\n
              echo [mysqld] > /mnt/conf.d/server-id.cnf\n
              # Add an offset to avoid reserved server-id=0 value.\n
              echo server-id=$((100 + $ordinal)) >> /mnt/conf.d/server-id.cnf\n
              # Copy appropriate conf.d files from config-map to emptyDir.\n
              if [[ $ordinal -eq 0 ]]; then\n
                cp /mnt/config-map/master.cnf /mnt/conf.d/\n
              else\n
                cp /mnt/config-map/slave.cnf /mnt/conf.d/\n
              fi\n
            "],
            "volumeMounts": [
              {"name": "conf", "mountPath": "/mnt/conf.d"},
              {"name": "config-map", "mountPath": "/mnt/config-map"}
            ]
          },
          {
            "name": "clone-mysql",
            "image": "gcr.io/google-samples/xtrabackup:1.0",
            "command": ["bash", "-c", "
              set -ex\n
              # Skip the clone if data already exists.\n
              [[ -d /var/lib/mysql/mysql ]] && exit 0\n
              # Skip the clone on master (ordinal index 0).\n
              [[ `hostname` =~ -([0-9]+)$ ]] || exit 1\n
              ordinal=${BASH_REMATCH[1]}\n
              [[ $ordinal -eq 0 ]] && exit 0\n
              # Clone data from previous peer.\n
              ncat --recv-only mysql-$(($ordinal-1)).mysql 3307 | xbstream -x -C /var/lib/mysql\n
              # Prepare the backup.\n
              xtrabackup --prepare --target-dir=/var/lib/mysql\n
            "],
            "volumeMounts": [
              {"name": "data", "mountPath": "/var/lib/mysql", "subPath": "mysql"},
              {"name": "conf", "mountPath": "/etc/mysql/conf.d"}
            ]
          }
        ]'
    spec:
      containers:
      - name: mysql
        image: mysql:5.7
        env:
        - name: MYSQL_ALLOW_EMPTY_PASSWORD
          value: "1"
        ports:
        - name: mysql
          containerPort: 3306
        volumeMounts:
        - name: data
          mountPath: /var/lib/mysql
          subPath: mysql
        - name: conf
          mountPath: /etc/mysql/conf.d
        resources:
          requests:
            cpu: 1
            memory: 1Gi
        livenessProbe:
          exec:
            command: ["mysqladmin", "ping"]
          initialDelaySeconds: 30
          timeoutSeconds: 5
        readinessProbe:
          exec:
            # Check we can execute queries over TCP (skip-networking is off).
            command: ["mysql", "-h", "127.0.0.1", "-e", "SELECT 1"]
          initialDelaySeconds: 5
          timeoutSeconds: 1
      - name: xtrabackup
        image: gcr.io/google-samples/xtrabackup:1.0
        ports:
        - name: xtrabackup
          containerPort: 3307
        command:
        - bash
        - "-c"
        - |
          set -ex
          cd /var/lib/mysql

          # Determine binlog position of cloned data, if any.
          if [[ -f xtrabackup_slave_info ]]; then
            # XtraBackup already generated a partial "CHANGE MASTER TO" query
            # because we're cloning from an existing slave.
            mv xtrabackup_slave_info change_master_to.sql.in
            # Ignore xtrabackup_binlog_info in this case (it's useless).
            rm -f xtrabackup_binlog_info
          elif [[ -f xtrabackup_binlog_info ]]; then
            # We're cloning directly from master. Parse binlog position.
            [[ `cat xtrabackup_binlog_info` =~ ^(.*?)[[:space:]]+(.*?)$ ]] || exit 1
            rm xtrabackup_binlog_info
            echo "CHANGE MASTER TO MASTER_LOG_FILE='${BASH_REMATCH[1]}',\
                  MASTER_LOG_POS=${BASH_REMATCH[2]}" > change_master_to.sql.in
          fi

          # Check if we need to complete a clone by starting replication.
          if [[ -f change_master_to.sql.in ]]; then
            echo "Waiting for mysqld to be ready (accepting connections)"
            until mysql -h 127.0.0.1 -e "SELECT 1"; do sleep 1; done

            echo "Initializing replication from clone position"
            # In case of container restart, attempt this at-most-once.
            mv change_master_to.sql.in change_master_to.sql.orig
            mysql -h 127.0.0.1 <<EOF
          $(<change_master_to.sql.orig),
            MASTER_HOST='mysql-0.mysql',
            MASTER_USER='root',
            MASTER_PASSWORD='',
            MASTER_CONNECT_RETRY=10;
          START SLAVE;
          EOF
          fi

          # Start a server to send backups when requested by peers.
          exec ncat --listen --keep-open --send-only --max-conns=1 3307 -c \
            "xtrabackup --backup --slave-info --stream=xbstream --host=127.0.0.1 --user=root"
        volumeMounts:
        - name: data
          mountPath: /var/lib/mysql
          subPath: mysql
        - name: conf
          mountPath: /etc/mysql/conf.d
        resources:
          requests:
            cpu: 100m
            memory: 100Mi
      volumes:
      - name: conf
        emptyDir: {}
      - name: config-map
        configMap:
          name: mysql
  volumeClaimTemplates:
  - metadata:
      name: data
      annotations:
        volume.alpha.kubernetes.io/storage-class: default
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 10Gi

```
- The StatefulSet controller starts one Pod at a time by their ordinal index. The StatefulSet controller waits until each Pod becomes Ready before starting the next pod.
- The first Init Container which named as `init-mysql`. It generates special MySQL config files based on the ordinal index.
- The ordinal index expressed at end of the Pod name is genrated by the script, which is returned by the hostname command.(mysql-0, mysql-1, mysql-2.....).
- Then the script saves the ordinal into a file called server-id.cnf in the MySQL `conf.d` directory. This translates the unique, stable identity provided by the StatefulSet controller into the domain of MySQL server IDs, which require the same properties.
- The script in the init-mysql container also applies either master.cnf or slave.cnf from the ConfigMap by copying the contents into `conf.d` .  The script simply assigns `ordinal 0 `to be the `master`, and eother ordinal to `slave`.

- The second Init Container, named `clone-mysql`. It performs a clone operation on a slave Pod the first time it starts up on an empty PersistentVolume. That means it copies all existing data from another running Pod, so its local state is consistent enough to begin replicating from the master.


Deploy this statefulset.
```
$ kubectl create -f mysql-statefulset.yaml
statefulset "mysql" created
```

Get the status of statefuleset.
```
$ kubectl get statefulset
NAME      DESIRED   CURRENT   AGE
mysql     3         3         1m
```

Get the status of pods.
```
$ kubectl get po
NAME      READY     STATUS    RESTARTS   AGE
mysql-0   2/2       Running   0          1m
mysql-1   2/2       Running   0          1m
mysql-2   2/2       Running   0          57s

```



We can send test queries to the MySQL master (hostname mysql-0.mysql) by running a temporary container with the mysql:5.7 image and running the mysql client binary.
```
kubectl run mysql-client --image=mysql:5.7 -i -t --rm --restart=Never --\
  mysql -h mysql-0.mysql <<EOF
CREATE DATABASE demo;
CREATE TABLE demo.messages (message VARCHAR(250));
INSERT INTO demo.messages VALUES ('Cloudyuga Pvt Ltd');
EOF

```
After sending the query press `ctrl+C`.


Now lets check the data we have recently inserted by using the `mysql-read` hostname .
```
$ kubectl run mysql-client1 --image=mysql:5.7 -i -t --rm --restart=Never --\
>   mysql -h mysql-read -e "SELECT * FROM demo.messages"


+-------------------+
| message           |
+-------------------+
| Cloudyuga Pvt Ltd |
+-------------------+

```

Now lets delete the pod running MySQL master(i.e. mysql-0 host).
```
$ kubectl delete pod mysql-0
```

Lets watch the `kubectl get pod`
```
$ kubectl get po
NAME      READY     STATUS        RESTARTS   AGE
mysql-0   2/2       Terminating   0          15m
mysql-1   2/2       Running       0          15m
mysql-2   2/2       Running       0          14m

$ kubectl get po
NAME      READY     STATUS        RESTARTS   AGE
mysql-0   0/2       Terminating   0          15m
mysql-1   2/2       Running       0          15m
mysql-2   2/2       Running       0          15m

$ kubectl get po
NAME      READY     STATUS    RESTARTS   AGE
mysql-0   2/2       Running   0          19s
mysql-1   2/2       Running   0          15m
mysql-2   2/2       Running   0          15m
```
The pod we have deleted has come up again.

Now again lets try to read the data from regerated pod(mysql-0).

```
$ kubectl run mysql-client12 --image=mysql:5.7 -i -t --rm --restart=Never --  mysql -h mysql-0.mysql -e "SELECT * FROM demo.messages"
+-------------------+
| message           |
+-------------------+
| Cloudyuga Pvt Ltd |
+-------------------+
```

Lets scaleup the stateful set application.
```
$ kubectl scale --replicas=4 statefulset mysql
```
Lets check the list of Pods.
```
$ kubectl get po
NAME      READY     STATUS    RESTARTS   AGE
mysql-0   2/2       Running   0          8m
mysql-1   2/2       Running   0          23m
mysql-2   2/2       Running   0          23m
mysql-3   1/2       Running   0          14s
```

We can also verify that these new server(mysql-3) have the data you added before they existed:
```
$ kubectl run mysql-client123 --image=mysql:5.7 -i -t --rm --restart=Never --\
>   mysql -h mysql-3.mysql -e "SELECT * FROM demo.messages"
+-------------------+
| message           |
+-------------------+
| Cloudyuga Pvt Ltd |
+-------------------+
```




## ETCD statefulset.

#### Prerequisites 
- Helm must be installed and the `tiller` pod must be running in the cluster. If Helm is not running then run following command in your cluster.
```
$ helm init
$HELM_HOME has been configured at /root/.helm.

Tiller (the Helm server-side component) has been installed into your Kubernetes Cluster.
Happy Helming!

```

#### Deploy ETCD statefulset cluster.

Add the repo of Helm chart.
```
$ helm repo add incubator http://storage.googleapis.com/kubernetes-charts-incubator
"incubator" has been added to your repositories
```
Deploy etcd stateful set cluster using the Helm install.
```
$ helm install --name my-release incubator/etcd
NAME:   my-release
LAST DEPLOYED: Fri Sep  8 10:40:27 2017
NAMESPACE: default
STATUS: DEPLOYED

RESOURCES:
==> v1/Service
NAME             CLUSTER-IP  EXTERNAL-IP  PORT(S)            AGE
my-release-etcd  None        <none>       2380/TCP,2379/TCP  1s

==> v1beta1/StatefulSet
NAME             DESIRED  CURRENT  AGE
my-release-etcd  3        1        1s
```
Get the list of Pods.
```
$ kubectl get pods -l "component=my-release-etcd"
NAME                READY     STATUS    RESTARTS   AGE
my-release-etcd-0   1/1       Running   0          2m
my-release-etcd-1   1/1       Running   0          2m
my-release-etcd-2   1/1       Running   0          2m
```

Get the list of StatefulSets.
```
$ kubectl get statefulset
NAME              DESIRED   CURRENT   AGE
my-release-etcd   3         3         6m
```

Get the status of `etcd` cluster health. at pod `my-release-etcd-0`
```
$ kubectl exec my-release-etcd-0 -- sh -c 'etcdctl cluster-health'

member 35ca710f77861a1f is healthy: got healthy result from http://my-release-etcd-0.my-release-etcd:2379
member 42ff7a05b378a1d6 is healthy: got healthy result from http://my-release-etcd-2.my-release-etcd:2379
member abbfaf20abf00e9b is healthy: got healthy result from http://my-release-etcd-1.my-release-etcd:2379
cluster is healthy
```
This output shows our cluster is healthy.






















































































































































