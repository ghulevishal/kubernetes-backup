## Create Secret.

Create a base64 conversion of your Data.
```
$ echo cloudyuga|base64
Y2xvdWR5dWdhCg==

$ echo cloudyuga123|base64
Y2xvdWR5dWdhMTIzCg==
```

From above Data create configuration file for creating secret.
```
apiVersion: v1
kind: Secret
metadata:
  name: mysecret
type: Opaque
data:
  username: Y2xvdWR5dWdhCg==
  password: Y2xvdWR5dWdhMTIzCg==
```

Create secrete from above file.
```
$ kubectl create -f secret.yaml
secret "mysecret" created
```

## Secret as Environment variables.

Create a configuration file of pod as shown below. In which we have given the Environment variable via secret. 
```
apiVersion: v1
kind: Pod
metadata:
  name: secret-env
spec:
  containers:
    - name: nginx
      image: nginx:1.9.1
      env:
        - name: SECRET_USERNAME
          valueFrom:
            secretKeyRef:
              name: mysecret
              key: username
        - name: SECRET_PASSWORD
          valueFrom:
            secretKeyRef:
              name: mysecret
              key: password
  restartPolicy: Never
```

Create a pod from above configuration.
```
$ kubectl create -f secret-env.yaml
pod "secret-env" created
```
Get list of Running pods.
```
$ kubectl get po
NAME                       READY     STATUS    RESTARTS   AGE
secret-env                 1/1       Running   0          6s
```
Exec into the pod `secret-env` and get the environment varables
```
$ kubectl exec -it secret-env sh
# printenv

MONGODB_PORT_27017_TCP=tcp://10.106.149.93:27017
KUBERNETES_SERVICE_PORT=443
KUBERNETES_PORT=tcp://10.96.0.1:443
RSVP_PORT_80_TCP_ADDR=10.111.126.233
HOSTNAME=secret-env
RSVP_PORT_80_TCP_PORT=80
RSVP_PORT_80_TCP_PROTO=tcp
HOME=/root
SECRET_PASSWORD=cloudyuga123

RSVP_PORT_80_TCP=tcp://10.111.126.233:80
TERM=xterm
MONGODB_SERVICE_HOST=10.106.149.93
KUBERNETES_PORT_443_TCP_ADDR=10.96.0.1
NGINX_VERSION=1.9.1-1~jessie
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
KUBERNETES_PORT_443_TCP_PORT=443
KUBERNETES_PORT_443_TCP_PROTO=tcp
MONGODB_SERVICE_PORT=27017
MONGODB_PORT=tcp://10.106.149.93:27017
SECRET_USERNAME=cloudyuga

RSVP_SERVICE_HOST=10.111.126.233
MONGODB_PORT_27017_TCP_ADDR=10.106.149.93
MONGODB_PORT_27017_TCP_PORT=27017
KUBERNETES_PORT_443_TCP=tcp://10.96.0.1:443
KUBERNETES_SERVICE_PORT_HTTPS=443
MONGODB_PORT_27017_TCP_PROTO=tcp
KUBERNETES_SERVICE_HOST=10.96.0.1
PWD=/
RSVP_SERVICE_PORT=80
RSVP_PORT=tcp://10.111.126.233:80
```

## Using secrets as volumes 

Create a configuration file for pod. In which we have used secret as volume.
```
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  labels:
    app: nginx
spec:
  containers:
  - name: nginx
    image: nginx:1.9.1
    ports:
    - containerPort: 80
    volumeMounts:
    - name: secret
      readOnly: true
      mountPath: /data/db
  volumes:
  - name: secret
    secret:
      secretName: mysecret

```

Create a pod from above configuration
```
$ kubectl create -f secret-vol.yaml
pod "nginx" created
```

Get the list of running pods.
```
$ kubectl get pod
NAME                       READY     STATUS    RESTARTS   AGE
nginx                      1/1       Running   0          1m
secret-env                 1/1       Running   0          8m
```

Exec into the pod `nginx` and check the mount path. Here we can find the Secret.
```
kubectl exec -it nginx sh
# cd /data/db
# ls
password  username
# cat password
cloudyuga123
# cat username
cloudyuga
#
```
## Create A ConfigMaps.

Create ConfigMaps from following configuration file. Create following like yaml file.
```
apiVersion: v1
kind: ConfigMap
metadata:
  name: customer1
data:
  TEXT1: Customer1_Company
  TEXT2: Welcomes You
  COMPANY: Customer1 Company Technology Pvt. Ltd.
```

Deploy ConfigMaps from above yaml file.
```
$ kubectl create -f config.yaml
configmap "customer1" created
```

Get the list of ConfigMaps.
```
$ kubectl get configmap
NAME        DATA      AGE
customer1   3         1m
```

## ConfigMaps as Environment variables.
Lets create following alike configuration file in which we have used the environment variables from the ConfigMaps.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp
spec:
  template:
    metadata:
      labels:
        app: rsvp
    spec:
      containers:
      - name: rsvp-app
        image: teamcloudyuga/rsvpapp
        env:
        - name: MONGODB_HOST
          value: mongodb
        - name: TEXT1
          valueFrom:
            configMapKeyRef:
              name: customer1
              key: TEXT1
        - name: TEXT2
          valueFrom:
            configMapKeyRef:
              name: customer1
              key: TEXT2
        - name: COMPANY
          valueFrom:
            configMapKeyRef:
              name: customer1
              key: COMPANY
        livenessProbe:
          httpGet:
            path: /
            port: 5000
          periodSeconds: 30
          timeoutSeconds: 1
          initialDelaySeconds: 50
        ports:
        - containerPort: 5000
          name: web-port

```

Deploy the Frontend application with above configuration file.
```
$ kubectl create -f rsvpconfig.yaml
deployment "rsvp" created
```

Lets create Backend for this Frontend and deploy it. Create follwoing like configuration yaml file.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp-db
spec:
  replicas: 1
  template:
    metadata:
      labels:
        appdb: rsvpdb
    spec:
      containers:
      - name: rsvpd-db
        image: mongo:3.3
        env:
        - name: MONGODB_DATABASE
          value: rsvpdata
        ports:
        - containerPort: 27017
```

Deploy this Backend application.
```
$ kubectl create -f backend.yaml
deployment "rsvp-db" created
```

Get the list of Deployments.

```
$ kubectl get deploy
NAME      DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
rsvp      1         1         1            1           4m
rsvp-db   1         1         1            1           2m
```

Lets create A services for Frontend and backend.

Create the service for Frontend from following configuration file.
```
apiVersion: v1
kind: Service
metadata:
  name: rsvp
  labels:
    app: rsvp
spec:
  type: NodePort
  ports:
  - port: 80
    targetPort: web-port
    protocol: TCP
  selector:
    app: rsvp

```
Deploy Frontend Service.
```
$ kubectl create -f frontendservice.yaml
service "rsvp" created
```

Create Service configuration file for Backend application.
```
apiVersion: v1
kind: Service
metadata:
  name: mongodb
  labels:
    app: rsvpdb
spec:
  ports:
  - port: 27017
    protocol: TCP
  selector:
    appdb: rsvpdb
```

Deploy the Backend service.
```
$ kubectl create -f backendservice.yaml
service "mongodb" created
```

Get list of Services.
```
$ kubectl get svc

NAME         CLUSTER-IP      EXTERNAL-IP   PORT(S)        AGE
kubernetes   10.96.0.1       <none>        443/TCP        27m
mongodb      10.107.242.62   <none>        27017/TCP      48s
rsvp         10.103.96.230   <nodes>       80:30921/TCP   48s
```
Now you can access your Frontend application at given port of master-IP and you can see there environment variable you have provided in ConfigMaps.

## ConfigMaps as Volumes 

Create Following like Pod configuration file to demonstrate ConfigMaps as volume.
```
apiVersion: v1
kind: Pod
metadata:
  name: con-demo
spec:
  containers:
    - name: test-container
      image: nginx:1.9.1
      command: [ "/bin/sh", "-c", "ls /tmp/config/" ]
      volumeMounts:
      - name: config-volume
        mountPath: /tmp/config
  volumes:
    - name: config-volume
      configMap:
        name: customer1
  restartPolicy: Never
```

Deploy the pod with above configuration file.
```
$ kubectl create -f configvolume.yaml
pod "con-demo" created
```
Get the list of Pods.
```
kubectl get po --show-all
NAME                       READY     STATUS      RESTARTS   AGE
con-demo                   0/1       Completed   0          37s
rsvp-3903261322-ksfxp      1/1       Running     7          22m
rsvp-db-1761629065-bq0x2   1/1       Running     0          20m
```

Get logs of the pod `con-demo`.
```
$ kubectl logs con-demo
COMPANY
TEXT1
TEXT2
```

## Create image pull Secret.

Lets create Image pull secret for Docker Hub.[Use your own Docker Hub login credentials]
```
$ kubectl create secret docker-registry regsecret --docker-username=username --docker-password=password --docker-email=your@email.com
secret "regsecret" created
```

Create Pod along with its service that will use the Docker registry image pull Secret.
```
---
apiVersion: v1
kind: Pod
metadata:
  name: private-reg
  labels:
    app: demo
spec:
  imagePullSecrets:
    - name: regsecret
  containers:
    - name: private-reg-container
      image: coolvbgarya/app  ## Use here your DockerHub private registry
      ports:
      - containerPort: 5000

---
apiVersion: v1
kind: Service
metadata:
  name: app
  labels:
    app: demo
spec:
  type: NodePort
  ports:
  - port: 80
    targetPort: 5000
    protocol: TCP
  selector:
    app: demo

```

Deploy the Application.

```
$ kubectl create -f  imagesecret.yaml
pod "private-reg" created
service "app" created
```

Get List of pods.
```
$ kubectl get po
NAME                       READY     STATUS    RESTARTS   AGE
private-reg                1/1       Running   0          6m
```

Get the list of the Services.
```
$  kubectl get svc
NAME         CLUSTER-IP      EXTERNAL-IP   PORT(S)        AGE
app          10.101.18.244   <nodes>       80:30342/TCP   7m
```




































































































