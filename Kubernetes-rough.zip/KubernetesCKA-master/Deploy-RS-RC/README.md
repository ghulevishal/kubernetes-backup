
## Pod
#### Create pod from following `pod-nginx.yaml` file.
```
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  labels:
     app: nginx
spec:
  containers:
  - name: nginx-demo
    image: nginx:1.9.1
    ports:
    - containerPort: 80
```
#### Deploy the pod from above yaml file.
```
$ kubectl create -f pod-nginx.yaml 
pod "nginx" created
```
#### Get list of running Pods.
```
$ kubectl get pod
NAME      READY     STATUS              RESTARTS   AGE
nginx     0/1       ContainerCreating   0          42s
```
## Replica Set
#### We are going to create ReplicaSet so it can create 3 replicas of above created `nginx` pod. Create the following `rs-nginx.yaml`.
```
apiVersion: extensions/v1beta1
kind: ReplicaSet
metadata:
  name: nginx
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx-app
        image: nginx
```
#### Deploy the Replica set from above yaml file.
```
$ kubectl create -f rs-nginx.yaml 
replicaset "nginx" created
```
#### Get the list of ReplicaSet.
```
$ kubectl get replicaset
NAME      DESIRED   CURRENT   READY     AGE
nginx     3         3         0         1m
```
#### We can check there are 3 pods (Replicas) are runnings which are managed by the ReplicaSet.
```
$ kubectl get po
NAME          READY     STATUS              RESTARTS   AGE
nginx         1/1       Running             0          5m
nginx-f12pv   0/1       ContainerCreating   0          7s
nginx-q94ld   0/1       ContainerCreating   0          7s
```
## Deployment

#### Create Deployment `deploy-nginx.yaml` file.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: nginx-deploy
spec:
  replicas: 2
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:1.9.1
        ports:
        - containerPort: 80
```
#### Create a Deployment from above yaml file.
```
$ kubectl create -f deploy-nginx.yaml 
deployment "nginx-deploy" created
```
#### Get the list of current Deployments.
```
$ kubectl get deployment
NAME           DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
nginx-deploy   2         2         2            0           36s
```
### Scaling the Deployments.

#### Scaling Up the Deployment to 5 Replicas.
```
$ kubectl scale deployment nginx-deploy --replicas=5
deployment "nginx-deploy" scaled
```
#### Check the Deployments and Replicas.
```
$ kubectl get deploy
NAME           DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
nginx-deploy   5         5         5            5           1m
```
#### Scale Down Deployment to 2 Replicas.
```
$ kubectl scale deployment nginx-deploy --replicas=2
deployment "nginx-deploy" scaled
```
#### Check the Deployments and Replicas.
```
$ kubectl get deploy
NAME           DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
nginx-deploy   2         2         2            2           1m
```
## Rollout: change the image of deployment.
```
$ kubectl set image deployment/nginx-deploy nginx=nginx:alpine
deployment "nginx-deploy" image updated
```
#### Check the Rollout status.
```
$ kubectl rollout status deployment/nginx-deploy
deployment "nginx-deploy" successfully rolled out
```
#### Check the History of Rollout.
```
$ kubectl rollout history deployment/nginx-deploy
deployments "nginx-deploy"
REVISION	CHANGE-CAUSE
1		        <none>
2	        	<none>
```
#### Rolling Back `undo`
```
$ kubectl rollout undo deployment/nginx-deploy
deployment "nginx-deploy" rolled back
```
#### Rolling back to specific Revision.
```
$ kubectl rollout undo deployment/nginx-deploy --to-revision=2
deployment "nginx-deploy" rolled back
```
## Multi containers  pod
#### Create Pod with Multi containers from following yaml file.
```
kind: Pod
metadata:
  name: multicontainer
spec:
  volumes:
  - name: html
    emptyDir: {}
  containers:
  - name: con1
    image: nginx
    volumeMounts:
    - name: html
      mountPath: /usr/share/nginx/html
  - name: con2
    image: debian
    volumeMounts:
    - name: html
      mountPath: /html
    command: ["/bin/sh", "-c"]
    args:
      - while true; do
          date >> /html/index.html;
          sleep 1;
        done
```
#### Create pod from above yaml file.
```
$ kubectl create -f multicontainer.yaml
pod "multicontainer" created
```
#### Check the list of Pods.
```
$ kubectl get po
NAME             READY     STATUS              RESTARTS   AGE
multicontainer   0/2       ContainerCreating   0          2m
```
## Init containers

#### Create Pod from following yaml.
```
kind: Pod
metadata:
  name: init-demo
spec:
  containers:
    - image: nginx:1.9.1
      name: cloudyuga-nginx
      volumeMounts:
      - name: demo
        mountPath: /tmp/
  initContainers:
    - image: nginx:1.9.1
      name: demo
      command: ["/bin/sh"]
      args: ["-c", "echo cloudyuga >>/tmp/demo.txt"] 
      volumeMounts:
      - name: demo
        mountPath: /tmp/
  restartPolicy: Never
  volumes:
    - name: demo
      hostPath:
        path: /tmp

```
#### Deploy above yaml file.
```
$ kubectl create -f init-pod.yaml 
pod "init-demo" created
```
#### Check the list of Pods.
```
kubectl get po 
NAME        READY     STATUS    RESTARTS   AGE
init-demo   1/1       Running   0          7s
```
#### Lets check the File created by the init container is present. For that ssh inti the pod n check the /tmp/demo.txt file.
```
$ kubectl exec -it init-demo sh
# cat /tmp/demo.txt
cloudyuga
# 
```
the `demo.txt` created by init-container was in `demo` volume and the same volume is mounted in `cloudyuga-nginx` containers.
Init containers gets executed before the cloudyuga-nginx` containers.


## Pod With Health Check.
A liveness probe we used in following demo, determines whether the container is running or not. If the liveness probe fails, then the container get killed. New container can be started as per mentioned in restart policy .

#### Create pod from following yaml file. This pod is correctly configured with liveness probe on 80 port.
```
apiVersion: v1
kind: Pod
metadata:
  name: nginx-liveness
  labels:
     app: nginx
spec:
  containers:
  - name: nginx-demo
    image: nginx:1.9.1
    ports:
    - containerPort: 80
    livenessProbe:
      httpGet:
        path: /
        port: 80
      initialDelaySeconds: 15
      timeoutSeconds: 1
```
#### Deploy above pod.
```
$ kubectl create -f nginx-liveness.yaml 
pod "nginx-liveness" created
```
#### Get the running pod list. This pod is correctly configured with liveness probe on 80 port. There may be no restarts.
```
$ kubectl get po
NAME             READY     STATUS    RESTARTS   AGE
nginx-liveness   1/1       Running   0          8s
```
#### Now lets create pod from following yaml file. This pod is not correctly configured with liveness probe on 81 port. 
```
apiVersion: v1
kind: Pod
metadata:
  name: nginx-liveness-fail
  labels:
     app: nginx
spec:
  containers:
  - name: nginx-demo
    image: nginx:1.9.1
    ports:
    - containerPort: 80
    livenessProbe:
      httpGet:
        path: /
        port: 81
      initialDelaySeconds: 15
      timeoutSeconds: 1
```
#### Deploy above pod.
```
$ kubectl create -f nginx-liveness-fail.yaml 
pod "nginx-liveness-fail" created
```
#### Get the list of running pods. This pod is not correctly configured with liveness probe on 81 port. 
```
$ kubectl get po
NAME                  READY     STATUS    RESTARTS   AGE
nginx-liveness        1/1       Running   0          8m
nginx-liveness-fail   1/1       Running   4          2m

```
#### You can get Addition information about this by executing this command `kubectl describe po nginx-liveness-fail`

## Explore labels of pods.
```
$ kubectl get pod --show-labels
NAME             READY     STATUS    RESTARTS   AGE       LABELS
nginx            0/1       Running   2          2m        app=webserver
```
## Annotation
#### create a pod with annotation as shown in below yaml.
```
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  labels:
     app: nginx
  annotations:
    build: demo
    builder: cloudyuga
spec:
  containers:
  - name: nginx-demo
    image: nginx:1.9.1
    ports:
    - containerPort: 80

```
#### Deploy Pod and Describe pod to see annotation.
```
$ kubectl create -f annotate-pod.yaml 
pod "nginx" created

$ kubectl describe po nginx
Name:		nginx
Namespace:	default
Node:		minikube/192.168.99.100
Start Time:	Fri, 01 Sep 2017 16:53:52 +0530
Labels:		app=nginx
Annotations:	build=demo
		builder=cloudyuga
Status:		Running
IP:		172.17.0.2
.
.
.
```
## Deploy Pod to specific Node

#### Create a pod with using Node selector
```
apiVersion: v1
kind: Pod
metadata:
  name: pod-demo
  labels:
    env: test
spec:
  containers:
  - name: pod-node
    image: nginx:1.9.1
  nodeSelector:
    disktype: ssd
```
#### Deploy the pod.
```
$ kubectl create -f nodeselector-pod.yaml 
pod "pod-demo" created
```
#### Check the status of recently deployed pod.
```
$ kubectl get po
NAME                  READY     STATUS             RESTARTS   AGE
pod-demo              0/1       Pending            0          7s
```
It is in pending state becuase it does not fing any node with label `disktype=ssd`
#### Lets check the labels of the nodes.
```
$ kubectl get nodes --show-labels
NAME       STATUS    AGE       VERSION   LABELS
minikube   Ready     21h       v1.7.0    beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/hostname=minikube
```
#### Add the label `disktype=ssd` to minikube node.
```
$ kubectl label nodes minikube disktype=ssd
node "minikube" labeled
```
#### Lets check the labels of the nodes and you can see `disktype=ssd` label present there.
```
$ kubectl get nodes --show-labels
NAME       STATUS    AGE       VERSION   LABELS
minikube   Ready     21h       v1.7.0    beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,disktype=ssd,kubernetes.io/hostname=minikube
```
#### Check the status of the pod now.
```
$ kubectl get po
NAME       READY     STATUS    RESTARTS   AGE
pod-demo   1/1       Running   0          5m

```
