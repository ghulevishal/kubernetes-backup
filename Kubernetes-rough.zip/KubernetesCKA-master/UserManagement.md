
## Service Accounts

## Normal Users

### Static password file
### OpenID connect Token 
### X509 Certificates 
### Webhooks 

```
❯ kubectl config  set-credentials admin --username=nkhare --password=cloudyuga
User "admin" set.

❯ cat ~/.kube/config
apiVersion: v1
clusters: []
contexts: []
current-context: ""
kind: Config
preferences: {}
users:
- name: admin
  user:
    password: cloudyuga
    username: nkhare
```
