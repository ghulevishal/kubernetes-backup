
## Sample App.
#### Create a sample `Nginx` App from following Deloyment configuration yaml file.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: sample-app
spec:
  replicas: 2
  template:
    metadata:
      labels:
        app: app
    spec:
      containers:
      - name: app
        image: nginx:1.9.1
        ports:
        - containerPort: 80
```
#### Deploy sample-app from above configuration file.
```
$ kubectl create -f sample-app.yaml
deployment "sample-app" created
```
#### Check the deployemnt and pods
```
$ kubectl get deploy
NAME         DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
sample-app   2         2         2            2           13s

$ kubectl get po
NAME                          READY     STATUS    RESTARTS   AGE
sample-app-3991448583-0tld5   1/1       Running   0          3m
sample-app-3991448583-mswkf   1/1       Running   0          3m
```
## Create Deployment configuration files for backend and frontend 

#### Deployment configuration for Frontend.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp
spec:
  template:
    metadata:
      labels:
        app: rsvp
    spec:
      containers:
      - name: rsvp-app
        image: teamcloudyuga/rsvpapp
        livenessProbe:
          httpGet:
            path: /
            port: 5000
          periodSeconds: 30
          timeoutSeconds: 1
          initialDelaySeconds: 50
        env:
        - name: MONGODB_HOST
          value: mongodb
        ports:
        - containerPort: 5000
          name: web-port
```
#### Create deployment from configuration.
```
$ kubectl create -f frontend.yaml 
deployment "rsvp" created

```
We are using `mongodb` database as backend for our application 
#### Deployment configuration for Backend.

```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp-db
spec:
  replicas: 1
  template:
    metadata:
      labels:
        appdb: rsvpdb
    spec:
      containers:
      - name: rsvpd-db
        image: mongo:3.3
        env:
        - name: MONGODB_DATABASE
          value: rsvpdata
        ports:
        - containerPort: 27017
```
#### Create deployment from above configuration.
```
$ kubectl create -f backend.yaml 
deployment "rsvp-db" created
```
#### Get the list of deployments.
```
$ kubectl get deploy
NAME      DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
rsvp      1         1         1            1           1m
rsvp-db   1         1         1            0           8s
```
#### Create the list of pods.
```
$ kubectl get po
NAME                       READY     STATUS    RESTARTS   AGE
rsvp-605011939-mk1b3       1/1       Running   1          3m
rsvp-db-1761629065-wkwxr   1/1       Running   0          1m
```
## Create Service configuration for Backend and frontend.
#### Create Service configuration file for Backend application. 
```
apiVersion: v1
kind: Service
metadata:
  name: mongodb
  labels:
    app: rsvpdb
spec:
  ports:
  - port: 27017
    protocol: TCP
  selector:
    appdb: rsvpdb

```
#### Deploy the Backend service.
```
$ kubectl create -f backendservice.yaml
service "mongodb" created
```
#### Create a Frontend service. We are going to use the Nodeport type service as our front end may be accessed from outside of cluster. Create following like configuration file.
```
apiVersion: v1
kind: Service
metadata:
  name: rsvp
  labels:
    app: rsvp
spec:
  type: NodePort
  ports:
  - port: 80
    targetPort: web-port
    protocol: TCP
  selector:
    app: rsvp
```
#### Deploy the Frontend service.
```
$ kubectl create -f frontendservice.yaml
service "rsvp" created
```
#### List all the services.
```
$ kubectl get svc
NAME         CLUSTER-IP       EXTERNAL-IP   PORT(S)        AGE
kubernetes   10.96.0.1        <none>        443/TCP        23m
mongodb      10.106.149.93    <none>        27017/TCP      10m
rsvp         10.111.126.233   <nodes>       80:31843/TCP   1m
```
our Front applications will be accessed at 31843 port of master IP.

## Pin the backend to run on specific node
#### Delete the Backend deployment.
```
$ kubectl delete deploy rsvp-db
```
#### Label the Nodes.[we have created the cluster of three nodes]
```
$ Kubectl get nodes
NAME      STATUS    AGE       VERSION
node1     Ready     14m       v1.7.0
node2     Ready     13m       v1.7.0
node3     Ready     4m        v1.7.0

$ kubectl label nodes node3 disktype=ssd
node "node3" labeled
```
#### Verify the labels
```
$ kubectl get nodes node3 --show-labels
NAME      STATUS    AGE       VERSION   LABELS
node3     Ready     21m       v1.7.0  beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,disktype=ssd,kubernetes.io/hostname=node3
```
#### Modify Backend deployment configuration file.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp-db
spec:
  replicas: 1
  template:
    metadata:
      labels:
        appdb: rsvpdb
    spec:
      containers:
      - name: rsvpd-db
        image: mongo:3.3
        env:
        - name: MONGODB_DATABASE
          value: rsvpdata
        ports:
        - containerPort: 27017
      nodeSelector:
        disktype: ssd
```
#### Check the Deployments.
Deploy Backend
```
$ kubectl create -f modified-backend.yaml 
deployment "rsvp-db" created
```
Check the deployment.
```
$ kubectl get deploy
NAME      DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
rsvp      1         1         1            1           16m
rsvp-db   1         1         1            1           2m
```
#### Access the FrontEnd.
