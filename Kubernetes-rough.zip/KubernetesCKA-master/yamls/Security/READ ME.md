#### Create the Docker Registry secret using following command in kubectl

```
$ kubectl create secret docker-registry regsecret --docker-username=<your-name> --docker-password=<your-pword> --docker-email=<your-email>

```
Use this `regsecret` secret in `private registry` demo.
