#### Start the minikube with RBAC enable.
```
$ minikube start --extra-config=apiserver.Authorization.Mode=RBAC
```

#### Crete new Namespace
```
$ kubectl create namespace office
namespace "office" created

```

#### Create a private key for your user. In this example, we will name the file employee.key:
```
$ openssl genrsa -out employee.key 2048
Generating RSA private key, 2048 bit long modulus
................+++
.......................................................................+++
e is 65537 (0x10001)

```

#### Create a certificate sign request employee.csr using the private key you just created. CN is for the username and O for the group
```
$ openssl req -new -key employee.key -out employee.csr -subj "/CN=employee/O=cloudyuga"
```

#### Generate the final certificate employee.crt by approving the certificate sign request, employee.csr
```
$ openssl x509 -req -in employee.csr -CA ~/.minikube/ca.crt -CAkey ~/.minikube/ca.key -CAcreateserial -out employee.crt -days 500
```
#### Add a new context with the new credentials for your Kubernetes cluster
```
$ kubectl config set-credentials employee --client-certificate=/home/vishal/work/RBAC/employee.crt --client-key=/home/vishal/work/RBAC/employee.key

$ kubectl config set-context employee-context --cluster=minikube --namespace=office --user=employee

```
#### Now you should get an access denied error when using the kubectl CLI with this configuration file. 

```
$ kubectl --context=employee-context get pods

Error from server (Forbidden): User "employee" cannot list pods in the namespace "office". (get pods)
```

#### Create `Role` as per `role.yaml` and Role-binding as per `role_binding.yaml`. 

#### After Deploying above role and binding execute following command.

```
$ kubectl --context=employee-context run --image nginx nginx
deployment "nginx" created

$ kubectl --context=employee-context get pods 
NAME                     READY     STATUS              RESTARTS   AGE
nginx-4217019353-gmqr2   0/1       ContainerCreating   0          4s

```
#### Try to get pod list from default namespace. It will give an error.

```
$ kubectl --context=employee-context get pods --namespace=default
Error from server (Forbidden): User "employee" cannot list pods in the namespace "default". (get pods)
```
#### Create `cluster role and binding` from `cluster_roles.yaml` and `cluster_role_binding.yaml` and deploy them.

#### Now try to get pod list from default namespace. You will get output.

```
$ kubectl --context=employee-context get pods --namespace=default
NAME                      READY     STATUS    RESTARTS   AGE
dnginx-2511571169-nmf26   1/1       Running   0          4m
```
