
#### Create a new demo namespace.

```
$ kubectl create namespace quota-mem-cpu-example
namespace "quota-mem-cpu-example" created
```

#### Create a Resource Quota object wthin above created name space.

```
$ kubectl create -f qouta.yaml --namespace=quota-mem-cpu-example
resourcequota "mem-cpu" created
```
#### Get the detailed information about the Resource Quota

```
$ kubectl get resourcequota mem-cpu --namespace=quota-mem-cpu-example --output=yaml

apiVersion: v1
kind: ResourceQuota
metadata:
  creationTimestamp: 2017-08-15T07:35:54Z
  name: mem-cpu
  namespace: quota-mem-cpu-example
  resourceVersion: "11901"
  selfLink: /api/v1/namespaces/quota-mem-cpu-example/resourcequotas/mem-cpu
  uid: 5eb13aa9-818c-11e7-9ac7-080027108760
spec:
  hard:
    limits.cpu: "1"
    limits.memory: 1Gi
    requests.cpu: 500m
    requests.memory: 512Mi
status:
  hard:
    limits.cpu: "1"
    limits.memory: 1Gi
    requests.cpu: 500m
    requests.memory: 512Mi
  used:
    limits.cpu: "0"
    limits.memory: "0"
    requests.cpu: "0"
    requests.memory: "0"

```

#### Deploy Demo 1 application within this namespace. Whose resource request can be fulfilled by the namespace

```
$ kubectl create -f demo1.yaml --namespace=quota-mem-cpu-example
pod "nginx" created

```
#### Deploy Demo 2 within this namespace. Whose resource request is exceeded than the Resource Quota.

```
kubectl create -f demo2.yaml --namespace=quota-mem-cpu-example
Error from server (Forbidden): error when creating "nginx1.yaml": pods "nginx" is forbidden: exceeded quota: mem-cpu, requested: limits.cpu=2,limits.memory=4Gi,requests.cpu=1,requests.memory=1Gi, used: limits.cpu=300m,limits.memory=400Mi,requests.cpu=200m,requests.memory=300Mi, limited: limits.cpu=1,limits.memory=1Gi,requests.cpu=500m,requests.memory=512Mi

```

#### Delete the namespace
```
$ kubectl delete namespace quota-mem-cpu-example
```
