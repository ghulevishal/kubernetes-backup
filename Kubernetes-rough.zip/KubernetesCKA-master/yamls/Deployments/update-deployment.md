#### To list of Deployment enter following command.
```
$ kubectl get deployments

NAME           DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
nginx-deploy   2         2         2            2           3m

```

#### To see the Deployment rollout status enter following command.

```
$ kubectl rollout status deployment/nginx-deploy
deployment "nginx-deploy" successfully rolled out
```

#### For updating a Deployment

```
$ kubectl set image deployment/nginx-deploy nginx=nginx:1.9.1
deployment "nginx-deploy" image updated
```
#### For Checking the History of RollOut

```
$ kubectl rollout history deployment/nginx-deploy
deployments "nginx-deploy"
REVISION	CHANGE-CAUSE
1		        <none>
2		        <none>

```

#### Rolling Back to a Previous Revision
Undo the current rollout and rollback to the previous revision

```
$ kubectl rollout undo deployment/nginx-deploy
deployment "nginx-deploy" rolled back

```

Rollback to specific revison

```
$ kubectl rollout undo deployment/nginx-deploy --to-revision=2
deployment "nginx-deploy" rolled back

```

#### scale a Deployment by using the following command:

```
$ kubectl scale deployment nginx-deploy --replicas 10
deployment "nginx-deploy" scaled

```

#### Pause the Deployments

```
$ kubectl rollout pause deployment/nginx-deploy
deployment "nginx-deploy" paused
```
### Resume the Deployments

```
$ kubectl rollout resume deploy/nginx-deploy
deployment "nginx-deploy" resumed
```
