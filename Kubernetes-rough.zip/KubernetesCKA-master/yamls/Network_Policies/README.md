#### Create Nginx deployment and expose it

```
$ kubectl run nginx --image=nginx --replicas=2
deployment "nginx" created

$ kubectl expose deployment nginx --port=80
service "nginx" exposed
```

#### Check the pods and services.

```
kubectl get svc,pod
NAME             CLUSTER-IP   EXTERNAL-IP   PORT(S)        AGE
svc/kubernetes   10.0.0.1     <none>        443/TCP        3h
svc/nginx        10.0.0.199   <none>        80/TCP         11s

NAME                        READY     STATUS    RESTARTS   AGE
po/nginx-4217019353-kt34n   1/1       Running   0          33s
po/nginx-4217019353-mmbj8   1/1       Running   0          33s

```
#### Deploy busybox and raech to the service.

```
$ kubectl run busybox --rm -ti --image=busybox /bin/sh
# wget --spider --timeout=1 nginx
Connecting to nginx (10.0.0.199:80)

```
#### Create the network policy it will limit the access of pod
#### create the network policy from `network_policy.yaml` and try to wget from busybox
```
kubectl run busybox --rm -ti --image=busybox /bin/sh
/ # wget --spider --timeout=1 nginx
Connecting to nginx (10.0.0.199:80)
wget: download timed out
```
