You can also create a secret object in a file first, in json or yaml format, and then create that object.

Each item must be base64 encoded:

```
$ echo -n "cloudyuga" | base64
Y2xvdWR5dWdh

$ echo -n "1f2d1e2e67df" | base64
Y2xvdWR5dWdhMTIz

```
