
Get the list of Nodes available in your cluster.
```
$ kubectl get nodes
NAME      STATUS    AGE       VERSION
node1     Ready     47m       v1.7.0
node2     Ready     46m       v1.7.0
node3     Ready     46m       v1.7.0
node4     Ready     46m       v1.7.0
node5     Ready     45m       v1.7.0
```
In this cluster `node1` is the Master node while remaining 4 nodes are the worker nodes.

So when we deploy the Daemon-set it deploy a pod on all the nodes(by default), or you can specify by using the `.spec.template.spec.nodeSelector` so the pods will be scheduled on specific nodes.
In this cluster, by default Daemon set will create 4 pods running on each node except the master node.

Lets create the DaemonSet from following configuration.
```
---
apiVersion: extensions/v1beta1
kind: DaemonSet
metadata:
  name: dsapp
  labels:
    app: dsapp
spec:
  template:
    metadata:
      labels:
        app: dsapp
    spec:
      containers:
      - name: dsapp-ctr
        image: coolvbgarya/app
        ports:
        - containerPort: 5000
          
---
apiVersion: v1
kind: Service
metadata:
  name: ds-svc
  labels:
    app: dsapp
spec:
  type: NodePort
  ports:
  - port: 5000
    targetPort: 5000
    protocol: TCP
  selector:
    app: dsapp

```

Deploy the Daemonset from above configuration file.
```
$ kubectl create -f daemonset.yaml
daemonset "dsapp" created
service "ds-svc" created
```

Get the list and status of Daemonset.
```
$ kubectl get ds
NAME      DESIRED   CURRENT   READY     UP-TO-DATE   AVAILABLE   NODE-SELECTOR   AGE
dsapp     4         4         4         4            4           <none>          33s
```

Get list of pods.
```
$ kubectl get po

NAME          READY     STATUS    RESTARTS   AGE
dsapp-902kp   1/1       Running   0          3m
dsapp-f0cvv   1/1       Running   0          3m
dsapp-fwmb2   1/1       Running   0          3m
dsapp-qtq6h   1/1       Running   0          3m
```

## Run DaemonSet Pods on specific Nodes.

Lets delete the earlier running DaemonSet and service.
```
$ kubectl delete ds dsapp
daemonset "dsapp" deleted

$ kubectl delete svc ds-svc
service "ds-svc" deleted
```

Label the nodes. lets label node 3 and 4 as disk=spinnig
```
$ kubectl label nodes node3 node4 disk=spinnig
node "node3" labeled
node "node4" labeled
```

Lets Modify above Daemonset Configuration file as shown below.
```
---
apiVersion: extensions/v1beta1
kind: DaemonSet
metadata:
  name: dsapp
  labels:
    app: dsapp
spec:
  template:
    metadata:
      labels:
        app: dsapp
    spec:
      containers:
      - name: dsapp-ctr
        image: coolvbgarya/app
        ports:
        - containerPort: 5000
      nodeSelector:
        disk: spinnig    
---
apiVersion: v1
kind: Service
metadata:
  name: ds-svc
  labels:
    app: dsapp
spec:
  type: NodePort
  ports:
  - port: 5000
    targetPort: 5000
    protocol: TCP
  selector:
    app: dsapp

```

Deploy the reconfigured Daemonset.
```
$ kubectl create -f ds-node.yaml
daemonset "dsapp" created
service "ds-svc" created
```

Get the list and status of Daemonset.
```
$ kubectl get ds
NAME      DESIRED   CURRENT   READY     UP-TO-DATE   AVAILABLE   NODE-SELECTOR   AGE
dsapp     2         2         2         2            2           disk=spinnig    1m
```
As we have given labels `disk=spinnig` to only 2 nodes. Hence 2 pods are created.

Get the list of Pods.
```
$ kubectl get pods
NAME          READY     STATUS    RESTARTS   AGE
dsapp-933b8   1/1       Running   0          2m
dsapp-wvg65   1/1       Running   0          2m
```


