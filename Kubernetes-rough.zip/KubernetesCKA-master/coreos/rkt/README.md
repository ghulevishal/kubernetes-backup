Problems
1. Only master node is showing up.
2. At masternode you have to modify `kube-apiserver.yaml` by adding `- --storage-backend=etcd2`. Orelse api-server container get stopped.

