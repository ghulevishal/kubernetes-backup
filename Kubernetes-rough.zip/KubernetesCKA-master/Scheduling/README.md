## Label a nodes. 

Get the list of Nodes available in your cluster.
```
$ kubectl get nodes
NAME      STATUS    AGE       VERSION
node1     Ready     47m       v1.7.0
node2     Ready     46m       v1.7.0
node3     Ready     46m       v1.7.0
node4     Ready     46m       v1.7.0
node5     Ready     45m       v1.7.0
```

Lets label the node5 as `node=demo`
```
$ kubectl label nodes node5 node=demo
kubectl label nodes node5 node=demo
```

Lets see the labels of node5.
```
$ kubectl get nodes node5 --show-labels
NAME      STATUS    AGE       VERSION   LABELS
node5     Ready     1h        v1.7.0    beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/hostname=node5,node=demo
```

## Use nodeSelector to schedule a Pod on a given node.

Lets create a pod configuration file as shown below so it can be deployed on the node5.

```
apiVersion: v1
kind: Pod
metadata:
  name: pod-demo
  labels:
    env: test
spec:
  containers:
  - name: pod-node
    image: nginx:1.9.1
  nodeSelector:
    node: demo
```

Deploy this pod.
```
$ kubectl create -f pod.yaml
pod "pod-demo" created
```

Check the list of Pods.
```
$ kubectl get po
NAME       READY     STATUS    RESTARTS   AGE
pod-demo   1/1       Running   0          1m
```

Check the pod running on node5.
```
$ kubectl get pods --template '{{range .items}}{{if eq .spec.nodeName "node5"}}{{.metadata.name}}{{"\n"}}{{end}}}{{end}}'
pod-demo
}'
```
In above command we have provided name of node

Or If you use describe command then you come to pod is deployed on node5.
```
$  kubectl describe pod demo-pod
Error from server (NotFound): pods "demo-pod" not found
[node1 ingress]$ kubectl describe pod pod-demo
Name:           pod-demo
Namespace:      default
Node:           node5/10.0.13.7
Start Time:     Wed, 06 Sep 2017 06:23:20 +0000
Labels:         env=test
Annotations:    <none>
Status:         Running
IP:             10.38.0.1
.
.
.

```

















