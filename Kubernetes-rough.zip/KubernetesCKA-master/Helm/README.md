## Initialize helm/tiller

Validate your cluster using following commands on `Master` node.
```
$ kubectl cluster-info
$ kubectl get nodes
$ kubectl get componentstatuses
```
Install `Helm` using following commands.
```
$ curl https://raw.githubusercontent.com/kubernetes/helm/master/scripts/get > get_helm.sh
$ chmod 700 get_helm.sh
$ ./get_helm.sh
```

Initialize the `Helm` and install the `Tiller`.
```
$ helm init
```

Confirm `Tiller` pod is deployed in kubernetes.
```
$ kubectl --namespace kube-system get pods | grep tiller
```

Before start using the `Helm`, create the `Cluster Role` by using following command.
```
kubectl create clusterrolebinding permissive-binding --clusterrole=cluster-admin --user=admin --user=kubelet --group=system:serviceaccounts;
```

## Search charts in stable repository 

You can search for charts in stable directory using the following command.
```
$  helm search mysql
NAME                    VERSION DESCRIPTION
stable/mysql            0.2.8   Fast, reliable, scalable, and easy to use open-...
stable/percona          0.2.1   free, fully compatible, enhanced, open source d...
stable/gcloud-sqlproxy  0.1.1   Google Cloud SQL Proxy
stable/mariadb          1.0.2   Fast, reliable, scalable, and easy to use open-...

```

## Deploy Mysql chart 
To deploy Mysql using Helm chart, execute following command.

```
$ helm install stable/mysql
NAME:   kissing-kangaroo
LAST DEPLOYED: Mon Sep  4 09:40:13 2017
NAMESPACE: default
STATUS: DEPLOYED

RESOURCES:
==> v1/PersistentVolumeClaim
NAME                    STATUS   VOLUME  CAPACITY  ACCESSMODES  STORAGECLASS  AGE
kissing-kangaroo-mysql  Pending  1s

==> v1/Service
NAME                    CLUSTER-IP      EXTERNAL-IP  PORT(S)   AGE
kissing-kangaroo-mysql  10.104.188.148  <none>       3306/TCP  1s

==> v1beta1/Deployment
NAME                    DESIRED  CURRENT  UP-TO-DATE  AVAILABLE  AGE
kissing-kangaroo-mysql  1        1        1           0          1s

==> v1/Secret
NAME                    TYPE    DATA  AGE
kissing-kangaroo-mysql  Opaque  2     1s
.
.
.
.
.
```

## Create a Helm Chart for a sample application

Create a chart of name rsvp.
```
$ helm create rsvp
Creating rsvp
```

List the contents of this directory.
```
$ ls rsvp/
Chart.yaml  charts  templates  values.yaml
```

Remove the contents of `template` directory.

```
$ rm -rf rsvp/templates/*.*
```

Create a deployment configuration in `rsvp/templates/` directory as shown below.

```
$ vi rsvp/templates/deployment.yaml

---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp
spec:
  template:
    metadata:
      labels:
        app: rsvp
    spec:
      containers:
      - name: rsvp-app
        image: teamcloudyuga/rsvpapp
        livenessProbe:
          httpGet:
            path: /
            port: 5000
          periodSeconds: 30
          timeoutSeconds: 1
          initialDelaySeconds: 50
        env:
        - name: MONGODB_HOST
          value: mongodb
        ports:
        - containerPort: 5000
          name: web-port

---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp-db
spec:
  replicas: 1
  template:
    metadata:
      labels:
        appdb: rsvpdb
    spec:
      containers:
      - name: rsvpd-db
        image: mongo:3.3
        env:
        - name: MONGODB_DATABASE
          value: rsvpdata
        ports:
        - containerPort: 27017

```

Create a Service configuration in `rsvp/templates/` directory as shown below.

```
$ vi rsvp/templates/service.yaml

---
apiVersion: v1
kind: Service
metadata:
  name: mongodb
  labels:
    app: rsvpdb
spec:
  ports:
  - port: 27017
    protocol: TCP
  selector:
    appdb: rsvpdb

---

apiVersion: v1
kind: Service
metadata:
  name: rsvp
  labels:
    app: rsvp
spec:
  type: NodePort
  ports:
  - port: 80
    targetPort: web-port
    protocol: TCP
  selector:
    app: rsvp
```

Verify that the chart is well-formatted.
```
$ helm lint --strict rsvp
==> Linting rsvp
[INFO] Chart.yaml: icon is recommended

1 chart(s) linted, no failures
```

Package Your chart.
```
helm package rsvp
Successfully packaged chart and saved it to: /cloudyuga/rsvp-0.1.0.tgz
```

Search for your package locally.
```
$ helm search -l
NAME                            VERSION         DESCRIPTION
local/rsvp                      0.1.0           A Helm chart for Kubernetes
```

Install your package by chart.
```
$ helm install --name rsvpdemo ./rsvp
NAME:   rsvpdemo
LAST DEPLOYED: Mon Sep  4 10:28:54 2017
NAMESPACE: default
STATUS: DEPLOYED

RESOURCES:
==> v1/Service
NAME     CLUSTER-IP      EXTERNAL-IP  PORT(S)       AGE
mongodb  10.96.192.63    <none>       27017/TCP     1s
rsvp     10.107.253.199  <nodes>      80:30575/TCP  1s

==> v1beta1/Deployment
NAME     DESIRED  CURRENT  UP-TO-DATE  AVAILABLE  AGE
rsvp     1        1        1           0          1s
rsvp-db  1        1        1           0          1s

```























