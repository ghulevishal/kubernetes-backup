#### git clone the repository in which the charts are stored.
```
git clone https://github.com/vishalcloudyuga/rsvphelm.git
```
#### Install the chart using the helm.
```
$ helm install --name rsvpdemo ./rsvp
NAME:   rsvpdemo
LAST DEPLOYED: Mon Sep  4 06:55:38 2017
NAMESPACE: default
STATUS: DEPLOYED

RESOURCES:
==> v1beta1/Deployment
NAME     DESIRED  CURRENT  UP-TO-DATE  AVAILABLE  AGE
rsvp     1        1        1           0          1s
rsvp-db  1        1        1           0          1s

==> v1/Service
NAME     CLUSTER-IP     EXTERNAL-IP  PORT(S)       AGE
rsvp     10.105.16.150  <nodes>      80:30307/TCP  1s
mongodb  10.103.134.4   <none>       27017/TCP     1s

```
