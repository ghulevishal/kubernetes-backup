## Prometheus 

- Pull Based 
- Multi Dimentional Database with Key Value 
- Its about Metrices, not for logging and tracing  

### Alert Defintions 

### Monitoring 

#### Application 

#### Cluster 
