## Create a deployment.
```
kubectl run nginx --image=nginx:1.9.1 --requests=cpu=100m --port=80
deployment "nginx" created

```

## Expose the deployment created.
```
$ kubectl expose deploy nginx --port=80 --container-port=80
service "nginx" exposed
```
## Setup HPA For CPU.
We have set up the HPA for 10% of CPU. If more than 10% of available CPU is used then another replica is created.

```
$ kubectl autoscale deploy nginx --cpu-percent=10 --min=1 --max=10
deployment "nginx" autoscaled
```
Get the list of HPA
```
$ kubectl get hpa
NAME      REFERENCE          TARGETS    MINPODS   MAXPODS   REPLICAS   AGE
nginx     Deployment/nginx   0% / 10%   1         10        1          1m

```
## Setup Load.
Lets run the load from busybox image.
```
$ kubectl run -i --tty load-generator --image=busybox /bin/sh

# while true; do wget -q -O- http://nginx.default.svc.cluster.local; done
```
## Checkout autoscaling 
After few minutes Open the another new terminal and check the status of HPA.
```
$ kubectl get hpa
NAME      REFERENCE          TARGETS     MINPODS   MAXPODS   REPLICAS   AGE
nginx     Deployment/nginx   18% / 10%   1         10        5          15m
```
Check the status of Deployment.

```
$ kubectl get deployment nginx
NAME      DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
nginx     7         7         7            7           21m
```
#### Stop the load.
In the terminal where we created the container with busybox image, terminate the load generation by typing `<Ctrl> + C`
 Get the status of HPA.

```
$ kubectl get hpa
NAME      REFERENCE          TARGETS    MINPODS   MAXPODS   REPLICAS   AGE
nginx     Deployment/nginx   0% / 10%   1         10        1          29m
```

