# RBAC
Role-Based Access Control (`RBAC`),  policies are important for the proper management of your cluster, RBAC policies allow you to specify which types of actions are permitted depending on the user and their role in your organization.
For e.g.
- Secure your cluster by granting privileged operations (accessing secrets, for example) only to admin users.
- Force user authentication in your cluster.

Lets get familier with following terms.
- Rules: A rule is a set of operations (verbs) that can be carried out on a group of resources which belong to different API Groups.
- Roles :  In a Role, the rules are applicable to a single namespace.
- ClusterRoles: In a ClusterRole is cluster-wide, so the rules are applicable to more than one namespace. 

## Create kubectl configuration files.
Before Demonstrate To Role and ClusterRole. We have to carry out following tasks.

Start Your Minikube with RBAC enabled mode.
```
$ minikube start --extra-config=apiserver.Authorization.Mode=RBAC 
```

Create a new directory.
```
$ mkdir -p /home/RBAC
$ cd /home/RBAC
```

Crete new Namespace `cloudyuga`.
```
$ kubectl create namespace cloudyuga
namespace "cloudyuga" created
```

Create Private Key for user named `nkhare`.
```
$ openssl genrsa -out nkhare.key 2048
Generating RSA private key, 2048 bit long modulus
............................................+++
............................+++
e is 65537 (0x10001)
```

Create a certificate sign request `nkhare.csr` using the private key you just have created.In following command CN is for the username and O for the group.
```
$ openssl req -new -key nkhare.key -out nkhare.csr -subj "/CN=nkhare/O=cloudyuga"

```

Generate the final certificate nkhare.crt by approving the certificate sign request, nkhare.csr.
```
$ openssl x509 -req -in nkhare.csr -CA ~/.minikube/ca.crt -CAkey ~/.minikube/ca.key -CAcreateserial -out nkhare.crt -days 500

```

Add a new context with the new credentials for your Kubernetes cluster.
```
$ kubectl config set-credentials nkhare --client-certificate=/home/RBAC/nkhare.crt --client-key=/home/RBAC/nkhare.key
$ kubectl config set-context nkhare-context --cluster=minikube --namespace=cloudyuga --user=nkhare
```

Try to get pod list with this above created context. You should get an access denied error when using the kubectl CLI with this configuration file. Because we have not described any roles or clusterrole for this user.
```
$ kubectl --context=nkhare-context get pods
Error from server (Forbidden): User "nkhare" cannot list pods in the namespace "cloudyuga". (get pods)
```
## Role.

Lets define some Roles within the `cloudyuga` namespace.
```
  kind: Role
  apiVersion: rbac.authorization.k8s.io/v1beta1
  metadata:
    namespace: cloudyuga
    name: deployment-manager
  rules:
  - apiGroups: ["", "extensions", "apps"]
    resources: ["deployments", "replicasets", "pods"]
    verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
```
In this yaml file we are creating the rule that allows a user to execute several operations on Deployments, Pods and ReplicaSets, which belong to the core (expressed by "" in the yaml file), apps, and extensions API Group.

Lets deploy the Role which are defined in above configuration file.
```
$ kubectl create -f role.yaml 
role "deployment-manager" created
```
## Role Bindings 

Lets Bind this roles to the user `nkhare`.
```
  kind: RoleBinding
  apiVersion: rbac.authorization.k8s.io/v1beta1
  metadata:
    name: deployment-manager-binding
    namespace: cloudyuga
  subjects:
  - kind: User
    name: nkhare
    apiGroup: ""
  roleRef:
    kind: Role
    name: deployment-manager
    apiGroup: ""
```
In this file, we are binding the deployment-manager Role to the User Account `nkhare` inside the `cloudyuga` namespace

Deploy the Role binding from above file.
```
$  kubectl create -f rolebinding.yaml 
rolebinding "deployment-manager-binding" created
```
When we have successfuly deployed the Role and Role-binding then execute the following commands.
```
$ kubectl --context=nkhare-context run nginx --image=nginx:1.9.1
deployment "nginx" created

$ kubectl --context=nkhare-context get pods
NAME                     READY     STATUS    RESTARTS   AGE
nginx-1530578888-fzv1n   1/1       Running   0          45s
```
Now, we can access the pods deployed within namespace `cloudyuga`.

If we run the same command with the `--namespace=default` argument, it will fail, as the `nkhare` user does not have access to this namespace.

```
$ kubectl --context=nkhare-context get pods --namespace=default
Error from server (Forbidden): User "nkhare" cannot list pods in the namespace "default". (get pods)
```
## Cluster Role

Lets define the Cluster Role as shown in following configuration file.
```
  kind: ClusterRole
  apiVersion: rbac.authorization.k8s.io/v1beta1
  metadata:
    name: cluster-manager
  rules:
  - apiGroups: ["", "extensions", "apps"]
    resources: ["deployments", "replicasets", "pods"]
    verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
```
Deploy this Cluster Role.
```
$ kubectl create -f cluster-role.yaml
clusterrole "cluster-manager" created
```
## Cluster Role Bindings.

Lets bind above created `cluster-manager` Cluster Role to user `nkhare`.
```
kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1beta1
metadata:
  name: cluster-manager-binding
subjects:
- kind: User
  name: nkhare # This allow manager to read any secrete present in all the namespaces
  apiGroup: ""
roleRef:
  kind: ClusterRole
  name: cluster-manager
  apiGroup: ""
```

Deploy this Cluster Role Binding.
```
$ kubectl create -f clusterrole-binding.yaml 
clusterrolebinding "cluster-manager-binding" created
```

If we run the same command with the `--namespace=default argument`, it will get output as we have configured the permissions for user `nkhare` for all the namespaces available in the cluster. 
```
$ kubectl run nginx --image=nginx:1.9.1
deployment "nginx" created

$ kubectl --context=nkhare-context get pods --namespace=default
NAME                     READY     STATUS    RESTARTS   AGE
nginx-1530578888-948kp   1/1       Running   0          3s

```
# Service Accounts.
A service account provides an identity for processes that run in a Pod.

While creating a pod, if you do not specify a service account then it is automatically assigned the default service account in the same namespace. Get the raw yaml for a pod you have created (using `kubectl get pods/podname -o yaml`), and you can see the spec.serviceAccountName field has been automatically set ot the default service account.

```
kubectl get po nginx-1530578888-948kp -o yamlapiVersion: v1
kind: Pod
metadata:
  .
  .
  .
spec:
  containers:
  - image: nginx:1.9.1
    imagePullPolicy: IfNotPresent
    name: nginx.
    .
    .
    .
  dnsPolicy: ClusterFirst
  nodeName: minikube
  restartPolicy: Always
  schedulerName: default-scheduler
  securityContext: {}
  serviceAccount: default
  serviceAccountName: default
  terminationGracePeriodSeconds: 30
.
.
.
```

Every namespace has one default Service Account. Lets see the list of available Service Account in various namespaces.
```
$ kubectl get serviceAccounts
NAME      SECRETS   AGE
default   1         17h

$ kubectl get serviceAccounts -n cloudyuga
NAME      SECRETS   AGE
default   1         1h

$ kubectl get serviceAccounts -n kube-system
NAME      SECRETS   AGE
default   1         17h
```

Lets create another Service account in default Namespace.
```
apiVersion: v1
kind: ServiceAccount
metadata:
  name: demo-service-account
```

Deploy above configuration file.
```
$ kubectl create -f serviceaccount.yaml 
serviceaccount "demo-service-account" created
```

Get the list of Service Accounts.
```
$ kubectl get serviceAccounts
NAME                   SECRETS   AGE
default                1         17h
demo-service-account   1         35s
```

Get the complete details of the Service Accounts.
```
$  kubectl get serviceaccounts demo-service-account -o yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  creationTimestamp: 2017-09-05T05:41:12Z
  name: demo-service-account
  namespace: default
  resourceVersion: "16611"
  selfLink: /api/v1/namespaces/default/serviceaccounts/demo-service-account
  uid: d3c6be43-91fc-11e7-9b7f-080027b03fdb
secrets:
- name: demo-service-account-token-t6qnx
```

Delete the Service Account.
```
$ kubectl delete serviceaccount demo-service-account
```
#### Attach ImagePullSecrets to a service account.

Get the list of secret and find ImagePullSecret.
```
$ kubectl get secrets
NAME                  TYPE                                  DATA      AGE
default-token-qhb6n   kubernetes.io/service-account-token   3         17h
regsecret             kubernetes.io/dockercfg               1         1m
```
Here `regsecret` is the ImagePullSecret.

```
$ kubectl patch serviceaccount default -p '{"imagePullSecrets": [{"name": "regsecret"}]}'
serviceaccount "default" patched
```
Get the detailed output of Service Account.
```
$ kubectl get serviceaccounts default -o yaml
apiVersion: v1
imagePullSecrets:
- name: regsecret
kind: ServiceAccount
metadata:
  creationTimestamp: 2017-09-04T12:15:18Z
  name: default
  namespace: default
  resourceVersion: "18473"
  selfLink: /api/v1/namespaces/default/serviceaccounts/default
  uid: b6fae402-916a-11e7-b395-080027b03fdb
secrets:
- name: default-token-qhb6n
```

From now if you create any pod. And if you execute `kubectl get pods/podname -o yaml` It'sspec section will be showing following like information of ImagePullSecret.
```
.
.
.
spec:
  imagePullSecrets:
  - name: regsecret
.
.
.
```

