#### Create `Blue` Deployment and Service.

```
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: webserver
spec:
  replicas: 2
  template:
    metadata:
      labels:
        app: webserver
    spec:
      containers:
      - name: webserver
        image: nginx:1.9.1
        ports:
        - containerPort: 80


---
apiVersion: v1
kind: Service
metadata:
  name: web-service
  labels:
    run: web-service
spec:
  type: NodePort
  ports:
  - port: 80
    protocol: TCP
  selector:
    app: webserver

```

Deploy the Deployment and service of Blue.
```
$ kubectl create -f blue.yaml 
deployment "webserver" created
service "web-service" created
```

#### Create `Green` Deployment and Service configuration file.
```
---

apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: dsapp
  labels:
    app: dsapp
spec:
  template:
    metadata:
      labels:
        app: dsapp
    spec:
      containers:
      - name: dsapp-ctr
        image: coolvbgarya/app
        ports:
        - containerPort: 5000

---
apiVersion: v1
kind: Service
metadata:
  name: ds-svc
  labels:
    app: dsapp
spec:
  type: NodePort
  ports:
  - port: 80
    targetPort: 5000
    protocol: TCP
  selector:
    app: dsapp


```
Deploy this Green deployments

````
$ Kubectl create -f green.yaml
service "ds-svc" created
deployment "dsapp" created

```
## Create the ingress object - Virtual Host based

Create ingress from following configuration file.

```
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: web-ingress
spec:
  rules:
  - host: blue.myweb.com
    http:
      paths:
      - backend:
          serviceName: web-service
          servicePort: 80
  - host: green.myweb.com
    http:
      paths:
      - backend:
          serviceName: ds-svc
          servicePort: 80

```

Deploy the configuration file.
```
$ kubectl create -f vhost-ingress.yaml
ingress "web-ingress" created
```

Lets get the status of ingress.
```
$ kubectl get ingress
NAME          HOSTS                            ADDRESS          PORTS     AGE
web-ingress   blue.myweb.com,green.myweb.com   192.168.99.100   80        2m

```

#### Edit the `/etc/hosts` file and create records of `blue.myweb.com` and `green.myweb.com` with your master IP.

Try the virtual hostname ingress by using curl. The command `curl blue.myweb.com` shows the output of nginx.
```
$ curl blue.myweb.com
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
<style>
    body {
        width: 35em;
        margin: 0 auto;
        font-family: Tahoma, Verdana, Arial, sans-serif;
.
.
.
```
Or you can go the web browser and enter ` blue.myweb.com`. You will see nginx running.

The command `curl green.myweb.com` shows the output of python application.
```
$ curl green.myweb.com
Hello World! from dsapp-vtsrw
```
If you enter `green.myweb.com` you will see python application is running.


## Create the ingress object - Path based ingress


Lets create path based ingress from following configuration.
```
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: path
  annotations:
    ingress.kubernetes.io/rewrite-target: /
spec:
  rules:
  - host: cy.myweb.com
    http:
      paths:
      - path: /dsapp
        backend:
          serviceName: ds-svc
          servicePort: 80
      - path: /web
        backend:
          serviceName: web-service
          servicePort: 80
```
#### Edit the `/etc/hosts` file and create records of `cy.myweb.com`  with your master IP.

Deploy the ingress.
```
$ kubectl create -f path-ingress.yaml 
ingress "path" created
```

Get the status of ingress.
```
$ kubectl get ingress
NAME      HOSTS          ADDRESS          PORTS     AGE
path      cy.myweb.com   192.168.99.100   80        48s
```

Lets check the path-based ingress.
Curl to the `cy.myweb.com/web` and see the output of curl.
```
$ curl cy.myweb.com/web
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
<style>
   .
   .
   .
   .
```
You can aslo check the in the browser `cy.myweb.com/web` will show you nginx running.

Curl to the `cy.myweb.com/dsapp` and see the output of curl.
```
$ curl cy.myweb.com/dsapp
Hello World! from dsapp-vtsrw
```
You can aslo check the in the browser `cy.myweb.com/dsapp` will show you python flask application running.















































