# Pod Security Policy.

A Pod Security Policy (PSP) is a cluster-level resource that controls the actions that a pod can perform and what it has the ability to access. The PodSecurityPolicy objects define a set of conditions that a pod must run with in order to be accepted into the system.

Before proccedding further to demonstrate first check is your cluster is supporting for PSP.
```
$ kubectl get psp
No resources found.
```
This means your cluster is supporting for PSP.

If you are using Minikube and your minikube is not supporting for the PSP then start your minikube with following command.
```
$ minikube start --extra-config=apiserver.GenericServerRunOptions.AdmissionControl=NamespaceLifecycle,LimitRanger,ServiceAccount,PersistentVolumeLabel,DefaultStorageClass,ResourceQuota,DefaultTolerationSeconds,PodSecurityPolicy
```
This command start minikube with enabling support for pod security policies and the other recommended admission controller plugins.

## RunAsUser
The runAsUser field in PSP defines which users a container can run as. Generally, it is used to prevent pods from running as the root user.

## SeLinux.
The SeLinux field defines the Security-Enhanced Linux (SELinux) security context for containers and only allows containers that match that context.

#### Create PSP to prevent pods from running with root privileges.

Lets create PSP policy from following configuration file.

```
apiVersion: extensions/v1beta1
kind: PodSecurityPolicy
metadata:
  name: restrict-root
spec:
  privileged: false
  runAsUser:
    rule: MustRunAsNonRoot
  seLinux:
    rule: RunAsAny
  fsGroup:
    rule: RunAsAny
  supplementalGroups:
    rule: RunAsAny
  volumes:
  - '*'
```
Lets Deploy this policy.
```
$ kubectl create -f restrict-pod.yaml 
podsecuritypolicy "restrict-root" created
```

Get the list and status of PSP.
```
$ kubectl get psp
NAME            PRIV      CAPS      SELINUX    RUNASUSER          FSGROUP    SUPGROUP   READONLYROOTFS   VOLUMES
restrict-root   false     []        RunAsAny   MustRunAsNonRoot   RunAsAny   RunAsAny   false            [*]
```

## Network Policy.

By default, all pods in a Kubernetes cluster can communicate freely with each other . In many environments, you can isolate the services running in pods from each other by applying network restrictions. 
We can improve the security of cluster applying following things.

- Only allow traffic between pods that form part of the same application. For example, in a frontend-backend application, only allow communication to the backend from frontend pods.
- Isolate pod traffic in namespaces. That is, a pod can only communicate with pods that belong to the same namespace.

For Demonstration lets create one nginx Deployment.
```
$ kubectl run nginx --image=nginx --replicas=2
deployment "nginx" created
```

Lets expose the `nginx` deployment on port 80.
```
$ kubectl expose deployment nginx --port=80
service "nginx" exposed
```

Lets Check the Services and deployment we created.
```
$ kubectl get svc,deploy

NAME             CLUSTER-IP   EXTERNAL-IP   PORT(S)        AGE
svc/kubernetes   10.0.0.1     <none>        443/TCP        9m
svc/nginx        10.0.0.152   <none>        80/TCP         1m

NAME           DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
deploy/nginx   2         2         2            2           2m

```
We can access the service from another pod. Lets check that.
```
$ kubectl run busybox --rm -ti --image=busybox /bin/sh
If you don't see a command prompt, try pressing enter.
/ # wget --spider --timeout=1 nginx
Connecting to nginx (10.0.0.152:80)
/ # 

```
 We have connected to the `nginx` from busybox pod. busybox pod has successfuly communicated with the `nginx` service.


Now create the Network policy so that only pod with label `app=demo` can communicate with nginx service.
Lets create the configuration file for network policy.
```
kind: NetworkPolicy
apiVersion: networking.k8s.io/v1
metadata:
  name: access-nginx
spec:
  podSelector:
    matchLabels:
      run: nginx
  ingress:
  - from:
    - podSelector:
        matchLabels:
          access: "true"
```
In this configuration file we have defined that pod running with the `run: nginx` label can only be accessed through the pod which have label `access: "true"`. We have restricted the access of our ngiinx service.

Deploy Network Policy.
```
$ kubectl create -f networkpolicy.yaml 
networkpolicy "access-nginx" created
```

Lets check whether we can access the nginx service from another pod.

```
$ kubectl run busybox --rm -ti --image=busybox /bin/sh
/ # wget --spider --timeout=1 nginx
Connecting to nginx (10.0.0.152:80)
wget: download timed out
```

Now Lets make pod with the correct label specified i the Network Policy and check whether we can conect to service or not?
```
$ kubectl run busybox --rm -ti --labels="access=true" --image=busybox /bin/sh
If you don't see a command prompt, try pressing enter.
/ # wget --spider --timeout=1 nginx
Connecting to nginx (10.0.0.152:80)
/ # 

```




















