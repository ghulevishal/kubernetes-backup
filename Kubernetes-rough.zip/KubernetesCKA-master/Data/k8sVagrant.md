#### Install `Vagrant` on your Ubuntu 16.04 workstation.
```
$ sudo apt-get update
$ apt-cache show vagrant
$ sudo apt-get install vagrant
$ vagrant -v
```

#### Install `Ansible` on your workstation.
```
$ sudo apt-add-repository ppa:ansible/ansible
$ sudo apt-get update
$ sudo apt-get install ansible
```

#### Install `python-netaddr` on your workstation.
```
$ sudo apt-get update
$ sudo apt-get install python-netaddr
```

#### Clone the `kubespray` git repository.
```
$ git clone https://github.com/kubernetes-incubator/kubespray.git
```

$ Change the Directory and Launch the cluster by using Vagrant.
```
$ cd kubespray
$ vagrant up
```

Note: To modify the CPU and RAM allocation please edit `kubespray/Vagrantfile` file
