#### Create 3 Ubuntu instances with RAM greater than 1GB on Digital Ocean and name them as Manager, Node1 and Node2.

#### Install `Docker` on all the instances i.e. Manager, Node1 and Node2 using following commands.
```
$ curl -fsSL get.docker.com -o get-docker.sh
$ sh get-docker.sh
```
#### Install the `kubectl` on all the instances i.e. Manager, Node1 and Node2 using following commands.
```
$ curl -LO https://storage.googleapis.com/kubernetes-release/release/v1.7.0/bin/linux/amd64/kubectl
$ chmod +x ./kubectl 
$ sudo mv ./kubectl /usr/local/bin/kubectl
```
#### Install `kubelet` and `kubeadm` on all the instances i.e. Manager, Node1 and Node2 using following commands.
```
$ apt-get update && apt-get install -y apt-transport-https
$ curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add -
$ cat <<EOF >/etc/apt/sources.list.d/kubernetes.list
deb http://apt.kubernetes.io/ kubernetes-xenial main
EOF
$ apt-get update
$ apt-get install -y kubelet kubeadm
```
#### Initializing `Master` instance by using following command. (execute only on Master node).
```
$ kubeadm init --pod-network-cidr=192.168.0.0/16
```
Please note down the `kubeadm join` command that will be shown as output of `kubeadm init` command.

#### Configure the `Master` node
```
$ mkdir -p $HOME/.kube
$ sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
$ sudo chown $(id -u):$(id -g) $HOME/.kube/config
```
#### Deploy the `Calico pod network` using following command.
```
$ kubectl apply -f http://docs.projectcalico.org/v2.4/getting-started/kubernetes/installation/hosted/kubeadm/1.6/calico.yaml
```
####  Join the worker node to cluster. In the terminal of both `Node1` and `Node2` execute the command that was output by `kubeadm init` command.

```
$ sudo su
$ kubeadm join --token <token> <master-ip>:<master-port>
```

#### Check available nodes in the cluster.
```
$ kubectl get nodes
```
#### Check the cluster information.
```
$ kubectl cluster-info
```
#### Check the status of cluster components.
```
$ kubectl get componentstatuses
```
## References
### 1. https://github.com/vishalcloudyuga/KubernetesCKA/edit/master/Create_K8s_DO_cluster.md
