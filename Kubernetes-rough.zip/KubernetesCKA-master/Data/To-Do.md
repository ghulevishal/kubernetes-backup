1. Pod (rsvp, mongo,rsvp-service, mongo-service)

2. Deployment ( rsvp, mongo,rsvp-service, mongo-service)

3. Services.

4. Replicasets

5. Service Discovery
  - Cluster-Ip [Mongodb]
  - NodePort [rsvp-web]
  
6. Ingress
  - Single service [rsvp]
  - multiple service [rsvp and nginx]
  
7. Graphana Monitoring
    - Graphana
    - InfluxDb
    - Heapster
    
8. Self Healing [rsvp with readyness probe]

9. Security
  - Set the security context for a Pod
  - Work with images securely.
  - Secure persistent key value store.
  
10. Volumes
  - persistent volumes.
  - persistent volume claims.
  - configure applications with persistent storage.


  
