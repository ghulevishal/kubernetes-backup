### Create 3 Ubuntu instances [node1, node2 and node3] on DO. On all instances install `ETCD`.
```
$ sudo mkdir -p /etc/etcd/
$ wget https://github.com/coreos/etcd/releases/download/v3.1.4/etcd-v3.1.4-linux-amd64.tar.gz
$ tar -xvf etcd-v3.1.4-linux-amd64.tar.gz
$ sudo mv etcd-v3.1.4-linux-amd64/etcd* /usr/bin/
$ sudo mkdir -p /var/lib/etcd
```
### Create TLS certificates. [on node1]

#### Create CA perform this on `node1`.
```
$ mkdir /root/etcd-certificate
$ cd /root/etcd-certificate
$ openssl genrsa -out ca-key.pem 2048
$ openssl req -x509 -new -nodes -key ca-key.pem -days 10000 -out ca.pem -subj "/CN=etcd-ca"

```
#### ETCD node1 certificate generation.
```
$ vim openssl.conf


[req]
req_extensions = v3_req
distinguished_name = req_distinguished_name

[req_distinguished_name]

[ v3_req ]
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names

[ ssl_client ]
extendedKeyUsage = clientAuth, serverAuth
basicConstraints = CA:FALSE
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid,issuer
subjectAltName = @alt_names

[ v3_ca ]
basicConstraints = CA:TRUE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names
authorityKeyIdentifier=keyid:always,issuer

[alt_names]
DNS.1 = localhost
DNS.2 = node1
IP.1 = 165.227.103.232
IP.2 = 127.0.0.1
```
#### create certificates from above openssl.conf.
```
$ CONFIG=`echo $PWD/openssl.conf`
$ openssl genrsa -out member-node1-key.pem 2048
$ openssl req -new -key member-node1-key.pem -out member-node1.csr -subj "/CN=node1" -config ${CONFIG}
$ openssl x509 -req -in member-node1.csr -CA ca.pem -CAkey ca-key.pem -CAcreateserial -out member-node1.pem -days 3650 -extensions ssl_client -extfile ${CONFIG}
```
#### Remove openssl.conf.
```
$ rm openssl.conf.
```

#### ETCD node2 certificate generation.
```
$ vim openssl.conf

[req]
req_extensions = v3_req
distinguished_name = req_distinguished_name

[req_distinguished_name]

[ v3_req ]
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names

[ ssl_client ]
extendedKeyUsage = clientAuth, serverAuth
basicConstraints = CA:FALSE
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid,issuer
subjectAltName = @alt_names

[ v3_ca ]
basicConstraints = CA:TRUE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names
authorityKeyIdentifier=keyid:always,issuer

[alt_names]
DNS.1 = localhost
DNS.2 = node2
IP.1 = 165.227.103.235
IP.2 = 127.0.0.1
```

#### create certificates from above openssl.conf.
```
$ CONFIG=`echo $PWD/openssl.conf`
$ openssl genrsa -out member-node2-key.pem 2048
$ openssl req -new -key member-node2-key.pem -out member-node2.csr -subj "/CN=node2" -config ${CONFIG}
$ openssl x509 -req -in member-node2.csr -CA ca.pem -CAkey ca-key.pem -CAcreateserial -out member-node2.pem -days 3650 -extensions ssl_client -extfile ${CONFIG}
```
#### Remove openssl.conf.
```
$ rm openssl.conf.
```

#### ETCD node3 certificate generation
```
$ vim openssl.conf

[req]
req_extensions = v3_req
distinguished_name = req_distinguished_name

[req_distinguished_name]

[ v3_req ]
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names

[ ssl_client ]
extendedKeyUsage = clientAuth, serverAuth
basicConstraints = CA:FALSE
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid,issuer
subjectAltName = @alt_names

[ v3_ca ]
basicConstraints = CA:TRUE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names
authorityKeyIdentifier=keyid:always,issuer

[alt_names]
DNS.1 = localhost
DNS.2 = node3
IP.1 = 165.227.103.229
IP.2 = 127.0.0.1
```

#### create certificates from above openssl.conf.
```
$ CONFIG=`echo $PWD/openssl.conf`
$ openssl genrsa -out member-node3-key.pem 2048
$ openssl req -new -key member-node3-key.pem -out member-node3.csr -subj "/CN=node3" -config ${CONFIG}
$ openssl x509 -req -in member-node3.csr -CA ca.pem -CAkey ca-key.pem -CAcreateserial -out member-node3.pem -days 3650 -extensions ssl_client -extfile ${CONFIG}
```

### Copy all the contents of `/root/etcd-certificate` on all the 3 nodes

### Fixing permissions on all etcd nodes at required directory and files.[on each node].

```
$ mkdir -p /etc/ssl/etcd/ssl/
$ cp -rvp /root/etcd-certificate/*.pem /etc/ssl/etcd/ssl/
$ chmod -Rv 550 /etc/ssl/etcd/
$ chmod 440 /etc/ssl/etcd/ssl/*.pem
```
### Create services.
#### Create ETCD service on node1. 

```
$ cd /etc/systemd/system/

cat > etcd.service <<EOF
[Unit]
Description=etcd
Documentation=https://github.com/coreos

[Service]
ExecStart=/usr/bin/etcd \\
  --name node1 \\
  --cert-file=/etc/ssl/etcd/ssl/member-node1.pem \\
  --key-file=/etc/ssl/etcd/ssl/member-node1-key.pem \\
  --peer-cert-file=/etc/ssl/etcd/ssl/member-node1.pem \\
  --peer-key-file=/etc/ssl/etcd/ssl/member-node1-key.pem \\
  --trusted-ca-file=/etc/ssl/etcd/ssl/ca.pem \\
  --peer-trusted-ca-file=/etc/ssl/etcd/ssl/ca.pem \\
  --peer-client-cert-auth \\
  --client-cert-auth \\
  --initial-advertise-peer-urls https://165.227.103.232:2380 \\
  --listen-peer-urls https://165.227.103.232:2380 \\
  --listen-client-urls https://165.227.103.232:2379,http://127.0.0.1:2379 \\
  --advertise-client-urls https://165.227.103.232:2379 \\
  --initial-cluster-token etcd-cluster-0 \\
  --initial-cluster node1=https://165.227.103.232:2380,node2=https://165.227.103.235:2380,node3=https://165.227.103.229:2380 \\
  --initial-cluster-state new \\
  --data-dir=/var/lib/etcd
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
```
#### Create ETCD service on node2
```
$ cd /etc/systemd/system/

cat > etcd.service <<EOF
[Unit]
Description=etcd
Documentation=https://github.com/coreos

[Service]
ExecStart=/usr/bin/etcd \\
  --name node2 \\
  --cert-file=/etc/ssl/etcd/ssl/member-node2.pem \\
  --key-file=/etc/ssl/etcd/ssl/member-node2-key.pem \\
  --peer-cert-file=/etc/ssl/etcd/ssl/member-node2.pem \\
  --peer-key-file=/etc/ssl/etcd/ssl/member-node2-key.pem \\
  --trusted-ca-file=/etc/ssl/etcd/ssl/ca.pem \\
  --peer-trusted-ca-file=/etc/ssl/etcd/ssl/ca.pem \\
  --peer-client-cert-auth \\
  --client-cert-auth \\
  --initial-advertise-peer-urls https://165.227.103.235:2380 \\
  --listen-peer-urls https://165.227.103.235:2380 \\
  --listen-client-urls https://165.227.103.235:2379,http://127.0.0.1:2379 \\
  --advertise-client-urls https://165.227.103.235:2379 \\
  --initial-cluster-token etcd-cluster-0 \\
  --initial-cluster node1=https://165.227.103.232:2380,node2=https://165.227.103.235:2380,node3=https://165.227.103.229:2380 \\
  --initial-cluster-state new \\
  --data-dir=/var/lib/etcd
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
```

#### Create ETCD service on node3
```
$ cd /etc/systemd/system/

cat > etcd.service <<EOF
[Unit]
Description=etcd
Documentation=https://github.com/coreos

[Service]
ExecStart=/usr/bin/etcd \\
  --name node3 \\
  --cert-file=/etc/ssl/etcd/ssl/member-node3.pem \\
  --key-file=/etc/ssl/etcd/ssl/member-node3-key.pem \\
  --peer-cert-file=/etc/ssl/etcd/ssl/member-node3.pem \\
  --peer-key-file=/etc/ssl/etcd/ssl/member-node3-key.pem \\
  --trusted-ca-file=/etc/ssl/etcd/ssl/ca.pem \\
  --peer-trusted-ca-file=/etc/ssl/etcd/ssl/ca.pem \\
  --peer-client-cert-auth \\
  --client-cert-auth \\
  --initial-advertise-peer-urls https://165.227.103.229:2380 \\
  --listen-peer-urls https://165.227.103.229:2380 \\
  --listen-client-urls https://165.227.103.229:2379,http://127.0.0.1:2379 \\
  --advertise-client-urls https://165.227.103.229:2379 \\
  --initial-cluster-token etcd-cluster-0 \\
  --initial-cluster node1=https://165.227.103.232:2380,node2=https://165.227.103.235:2380,node3=https://165.227.103.229:2380 \\
  --initial-cluster-state new \\
  --data-dir=/var/lib/etcd
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF


```

### Start service on all the three nodes and check the status.
```
$ sudo systemctl daemon-reload
$ sudo systemctl enable etcd
$ sudo systemctl start etcd
$ sudo systemctl status etcd --no-pager
```

#### Export API version environment variableon the all three nodes.

```
$ export ETCDCTL_API=3
```

#### Verify it as. 

```
$ sudo etcdctl \
  --ca-file=/etc/ssl/etcd/ssl/ca.pem \
  --cert-file=/etc/ssl/etcd/ssl/member-node3.pem \
  --key-file=/etc/ssl/etcd/ssl/member-node3-key.pem \
  cluster-health
```









