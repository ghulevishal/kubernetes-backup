#### Validate your cluster using following commands on `Master` node.
```
$ kubectl cluster-info
$ kubectl get nodes
$ kubectl get componentstatuses
```
#### Install `Helm` using following commands.
```
$ curl https://raw.githubusercontent.com/kubernetes/helm/master/scripts/get > get_helm.sh
$ chmod 700 get_helm.sh
$ ./get_helm.sh
```
#### Initialize the `Helm` and install the `Tiller`.
```
$ helm init
```
#### confirm `Tiller` pod is deployed in kubernetes.
```
$ kubectl --namespace kube-system get pods | grep tiller
```
#### Before start using the `Helm`, create the `Cluster Role` by using following command.
```
kubectl create clusterrolebinding permissive-binding --clusterrole=cluster-admin --user=admin --user=kubelet --group=system:serviceaccounts;
```
#### Install the `Nginx Ingress Controller` using `Helm`.
```
$ helm install stable/nginx-ingress
```


## References.
### 1. https://docs.helm.sh/using_helm/#installing-helm
### 2. https://github.com/kubernetes/helm/issues/2224
