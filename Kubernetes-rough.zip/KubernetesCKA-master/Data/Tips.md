Check the status of components of K8s Cluster.
```
$ kubectl get componentstatuses
```

Create a new namespace.
```
$ kubectl create namespace cloudyuga
```

Deploy pod in specific namespace.
```
$  kubectl create -f pod.yaml --namespace=cloudyuga
```

Get pod from specific namespace.
```
$ kubectl get po -n cloudyuga
NAME      READY     STATUS    RESTARTS   AGE
nginx     1/1       Running   0          39s

```

Resouces utilized by pod or nodes [work betterly if heapster is installed with your cluster]
```
$ kubectl top pods nginx
$ kubectl top nodes
```

List APIs
```
kubectl api-versions
```
