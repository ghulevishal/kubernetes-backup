## Mounting volumes in different containers

#### Frontend
Create Deployment configuration for Frontent as shown below.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp
spec:
  template:
    metadata:
      labels:
        app: rsvp
    spec:
      containers:
      - name: rsvp-app
        image: teamcloudyuga/rsvpapp
        livenessProbe:
          httpGet:
            path: /
            port: 5000
          periodSeconds: 30
          timeoutSeconds: 1
          initialDelaySeconds: 50
        env:
        - name: MONGODB_HOST
          value: mongodb
        ports:
        - containerPort: 5000
          name: web-port
```

Create deployment from configuration.
```
$ kubectl create -f frontend.yaml 
deployment "rsvp" created

```

Create a Frontend service. We are going to use the Nodeport type service as our front end may be accessed from outside of cluster. Create following like configuration file.
```
apiVersion: v1
kind: Service
metadata:
  name: rsvp
  labels:
    app: rsvp
spec:
  type: NodePort
  ports:
  - port: 80
    targetPort: web-port
    protocol: TCP
  selector:
    app: rsvp
```

Deploy the Frontend service.
```
$ kubectl create -f frontendservice.yaml
service "rsvp" created
```
#### Backend.

Create following like Deployment configuration file. In which have mounted the `voldb` volume in the container.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp-db
spec:
  replicas: 1
  template:
    metadata:
      labels:
        appdb: rsvpdb
    spec:
      volumes:
        - name: voldb
          hostPath:
            path: /tmp
      containers:
      - name: rsvpd-db
        image: mongo:3.3
        volumeMounts:
        - name: voldb
          mountPath: /data/db
        env:
        - name: MONGODB_DATABASE
          value: rsvpdata
        ports:
        - containerPort: 27017

```

Create deployment from above configuration.
```
$ kubectl create -f backendvol.yaml
deployment "rsvp-db" created
```

Create Service configuration file for Backend application. 
```
apiVersion: v1
kind: Service
metadata:
  name: mongodb
  labels:
    app: rsvpdb
spec:
  ports:
  - port: 27017
    protocol: TCP
  selector:
    appdb: rsvpdb

```

Deploy the Backend service.
```
$ kubectl create -f backendservice.yaml
service "mongodb" created
```
Get the list of deployments.
```
$ kubectl get deploy
NAME      DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
rsvp      1         1         1            1           1m
rsvp-db   1         1         1            1           6s
```
Now access the front end via browser and make some entries in it. Now go to the terminal and delete the deployment `rsvp-db`.
```
$ kubectl delete deploy rsvp-db
deployment "rsvp-db" deleted
```
Again deploy the Backend.

```
$ kubectl create -f backendvol.yaml
deployment "rsvp-db" created
```

List the deployments.
```
$ kubectl get deploy
NAME      DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
rsvp      1         1         1            1           11m
rsvp-db   1         1         1            1           1m
```
Now Go to browser and try to access the Frontend and you will see the entries you made earlier are still there. We have mounted the DB in volumes. Though container is deleted, data is stored at volume and when new container of mongodb comes up then data from volume is mounted.

## Create a Persistent Volumes.

Make configuration file for Persistent volume (PV) as show below. This will create PV of 1GB.
```
kind: PersistentVolume
apiVersion: v1
metadata:
  name: pv0001
  labels:
    type: local
spec:
  capacity:
    storage: 1Gi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: "/tmp/data01"
```

Deploy a PV with above configuration.
```
$ kubectl create -f pv.yaml
persistentvolume "pv0001" created
```

Check the list of PVs.
```
 kubectl get pv
NAME      CAPACITY   ACCESSMODES   RECLAIMPOLICY   STATUS    CLAIM               STORAGECLASS   REASON  AGE
pv0001    1Gi        RWO           Retain          Bound     default/myclaim-1                          5m
```

## Create Persistent Volume Claims.

Create a configuration file for creating the Persistent Volume Claims (PVC). 
```
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: myclaim-1
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 0.5Gi
```

Deploy a PV with above configuration.
```
$ kubectl create -f pvclaim.yaml
persistentvolumeclaim "myclaim-1" created
```

Get list of PVC.
```
$ Kubectl get pvc
NAME        STATUS    VOLUME    CAPACITY   ACCESSMODES   STORAGECLASS   AGE
myclaim-1   Bound     pv0001    1Gi        RWO                          4s
```

## Using Persistent Volumes Claims, inside Pod/Deployment 
First delete the `rsvp-db` deployment (if present).

Lets Modify above Backend configuration file to demonstrate use of PVC.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rsvp-db
spec:
  replicas: 1
  template:
    metadata:
      labels:
        appdb: rsvpdb
    spec:
      volumes:
        - name: voldb
          persistentVolumeClaim:
           claimName: myclaim-1
      containers:
      - name: rsvpd-db
        image: mongo:3.3
        volumeMounts:
        - name: voldb
          mountPath: /data/db
        env:
        - name: MONGODB_DATABASE
          value: rsvpdata
        ports:
        - containerPort: 27017
 
```

Deploy the backend configured with PVC
```
$ kubectl create -f backendpvc.yaml
deployment "rsvp-db" created
```
### check pvc is properly configured.
Now access the front end via browser and make some entries in it. Now go to the terminal and delete the deployment `rsvp-db`.
```
$ kubectl delete deploy rsvp-db
deployment "rsvp-db" deleted
```
Again deploy the Backend.

```
$ kubectl create -f backendpvc.yaml
deployment "rsvp-db" created
```
Now Go to browser and try to access the Frontend and you will see the entries you made earlier are still there. 

## Storage Class.
- The beta version of dynamic provisioning in Kubernetes 1.4 & further, introduced a new API object called as StorageClass.
- This object allow cluster administrator to use different storage system in cluster with proper specification.
- Users don’t have to worry about the the complexity and headache of how storage is provisioned. This feature allow end users to select multiple storage option.

Lets demonstrate how storage class is created.

We are going to create the storage class named `slow-disk`. Which has slow speed disk and the storage is provisoned by Googl cloud engine.
```
kind: StorageClass
apiVersion: storage.k8s.io/v1beta1
metadata:
  name: slow-disk
provisioner: kubernetes.io/gce-pd
parameters:
  type: pd-standard
```

Lets deploy this Storage class.
```
$ kubectl create -f slow.yaml
storageclass "slow-disk" created
```

Lets create the Storage class with provider as `minikube-hostpath`
```
kind: StorageClass
apiVersion: storage.k8s.io/v1beta1
metadata:
  name: demo
provisioner: kubernetes.io/minikube-hostpath
```
Deploy the storage class.
```
$ kubectl create -f demo-storageclass.yaml 
storageclass "demo" created
```
Get the list and status of Sorage Class.
```
$ kubectl get storageclass
NAME                 TYPE
demo                 kubernetes.io/minikube-hostpath   
slow-disk            kubernetes.io/gce-pd              
standard (default)   k8s.io/minikube-hostpath    
```




















