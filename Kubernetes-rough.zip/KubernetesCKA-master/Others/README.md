# Taints and toleration
Taints and tolerations work together to ensure that pods are not scheduled on inappropriate nodes.
- A taint is a new type that is part of the NodeSpec; when present on node, it prevents pods from scheduling onto the node unless the pod tolerates the taint (tolerations are listed in the PodSpec).  
- Tolerations are applied to pods, and allow the pods to schedule onto nodes with matching taints

Let Get list of Nodes of your cluster.
```
$ kubectl get nodes
NAME      STATUS    AGE       VERSION
node1     Ready     4m        v1.7.0
node2     Ready     5m        v1.7.0
node3     Ready     5m        v1.7.0
```

Lets add taint to the node2 using following command.
```
$ kubectl taint nodes node2 special=true:NoSchedule
node "node2" tainted
```
This command places a taint on node `node2`. The taint has key `special`, value `true`, and taint effect `NoSchedule`. This means that no pod will be able to schedule onto node2 unless it has a matching toleration.

Lets create A daemonset and it will run pod on all nodes. Create A daemonset configuration from following file.
```
apiVersion: extensions/v1beta1
kind: Daemonset
metadata:
  name: nginx-deploy
spec: 
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:1.9.1
        ports:
        - containerPort: 80
```
Deploy Daemonset
```
$ kubectl create -f ds.yaml
daemonset "nginx-deploy" created
```
Get the list of Daemonset.
```
$ kubectl get ds
NAME           DESIRED   CURRENT   READY     UP-TO-DATE   AVAILABLE   NODE-SELECTOR   AGE
nginx-deploy   1         1         1         1            1           <none>          11s
```

Actually we have 2 worker node, so there should be 2 pods running. i.e. one pod on each node. But as we have marked node2 as taint pod is not deployed on that node. 


Lets modify the Damonset with toleration specification.
```
apiVersion: extensions/v1beta1
kind: Daemonset
metadata:
  name: nginx-toleration
spec:
  template:
    metadata:
      labels:
        app: nginx1
    spec:
      tolerations: 
      - key: "special"
        operator: "Equal"
        value: "true"
        effect: "NoSchedule"
      containers:
      - name: nginx
        image: nginx:1.9.1
        ports:
        - containerPort: 80

```

Deploy the modified DaemonSet.
```
$  kubectl create -f ds-tolerate.yaml
daemonset "nginx-toleration" created
```
Get the list of Daemonset.
```
$ kubectl get ds
NAME               DESIRED   CURRENT   READY     UP-TO-DATE   AVAILABLE   NODE-SELECTOR   AGE
nginx-deploy       1         1         1         1            1           <none>          8m
nginx-toleration   2         2         2         2            2           <none>          43s
```


# Mark Node Schedulable/Unschedulable.
Marking a node as unschedulable will prevent new pods from being scheduled to that node, but will not affect any existing pods on the node. This is useful as a preparatory step before a node reboot, etc. For example, to mark a node1 as unschedulable, run this command.

```
$ kubectl cordon node1
node "node1" cordoned
```
Get the list of nodes. and we can see node1 is marked as unschedulable.
```
$ kubectl get nodes
NAME      STATUS                     AGE       VERSION
node1     Ready,SchedulingDisabled   35m       v1.7.0
node2     Ready                      36m       v1.7.0
node3     Ready                      36m       v1.7.0
```

To mark node1 as schedulable again run following command.
```
$ kubectl uncordon node1
node "node1" uncordoned
```

Get the list of Nodes. All the nodes are schedulable.
```
$ kubectl get nodes
NAME      STATUS    AGE       VERSION
node1     Ready     38m       v1.7.0
node2     Ready     39m       v1.7.0
node3     Ready     39m       v1.7.0
```
# Drain Nodes.

First, identify the name of the node you wish to drain. You can list all of the nodes in your cluster with.
```
$ kubectl get nodes
NAME      STATUS    AGE       VERSION
node1     Ready     38m       v1.7.0
node2     Ready     39m       v1.7.0
node3     Ready     39m       v1.7.0
```

You can use kubectl drain to safely evict all of your pods from a node before you perform maintenance on the node.
```
$ kubectl drain node1
node "node1" cordoned
```
 After that you can delete node or Make node schedulable again with following command.
 ```
$ kubectl uncordon node1
node "node1" uncordoned
 ```

# Update field(s) of a resource using using kubectl patch 


To demonstrate the `Kubectl patch` lets create the deployment from following configuration file.
```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: nginx
spec:
  replicas: 2
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:alpine
        ports:
        - containerPort: 80

```

Create Deployment.
```
$  kubectl create -f nginx-deploy.yaml
deployment "nginx" created
```

Lets update the container image usig the `kubectl patch`

```
$ kubectl patch deployment nginx -p '{"spec": {"template": {"spec": {"containers": [{"name": "nginx", "image": "nginx:1.9.1"}]}}}}'
```

# Quota Management 
A resource quota is responsible for limiting resource consumption per namespace. It can limit the quantity of objects that can be created in a namespace by type, as well as the total amount of compute resources that may be consumed by resources in that project.

For Demonstration Lets execute following commands.

Create a new demo namespace.
```
$ kubectl create namespace quota-mem-cpu-example
namespace "quota-mem-cpu-example" created
```
Create a Resource-Qouta object within our newly created namespace.
```
apiVersion: v1
kind: ResourceQuota
metadata:
  name: mem-cpu
  namespace: quota-mem-cpu-example
spec:
  hard:
    requests.cpu: "0.5"
    requests.memory: 512Mi
    limits.cpu: "1"
limits.memory: 1Gi
```
Deploy this object.
```
$ kubectl create -f qouta.yaml
resourcequota "mem-cpu" created
```

Get the detailed information about the Resource Quota.
```
$ $ kubectl create namespace quota-mem-cpu-example
namespace "quota-mem-cpu-example" created
[node4 cri-o]$ cd[node4 ~]$ vi resourceqouta.yaml
[node4 ~]$ kubectl create -f resourceqouta.yaml
resourcequota "mem-cpu" created
[node4 ~]$ kubectl get resourcequota mem-cpu --namespace=quota-mem-cpu-example --output=yaml
apiVersion: v1
kind: ResourceQuota
metadata:
  creationTimestamp: 2017-09-07T11:38:06Z
  name: mem-cpu
  namespace: quota-mem-cpu-example
  resourceVersion: "10540"
  selfLink: /api/v1/namespaces/quota-mem-cpu-example/resourcequotas/mem-cpu
  uid: 0423c11e-93c1-11e7-b5ae-0242e7b4d4d4
spec:
  hard:
    limits.cpu: "1"    limits.memory: 1Gi
    requests.cpu: 500m
    requests.memory: 512Mi
status:
  hard:
    limits.cpu: "1"
    limits.memory: 1Gi
    requests.cpu: 500m
    requests.memory: 512Mi
  used:
    limits.cpu: "0"
    limits.memory: "0"
    requests.cpu: "0"
    requests.memory: "0"
```
Deploy Demo 1 application within this namespace. Whose resource request can be fulfilled by the namespace. Configure this application as below
```
apiVersion: v1
kind: Pod
metadata:
  namespace: quota-mem-cpu-example
  name: nginx-demo1
  labels:
     app: nginx
spec:
  containers:
  - name: nginx
    image: nginx:1.9.1
    ports:
    - containerPort: 80
    resources:
      limits:
        memory: "400Mi"
        cpu: "0.3"      
      requests:
        memory: "300Mi"
        cpu: "0.2"
```
Deploy this Application.
```
$ kubectl create -f demo1.yaml
pod "nginx-demo1" created
```

Deploy Demo 2 within this namespace. Whose resource request is exceeding the Resource Quota. Configure Demo 2 as like below configuration file.

```
apiVersion: v1
kind: Pod
metadata:
  namespace: quota-mem-cpu-example
  name: nginx
  labels:
     app: nginx
spec:
  containers:
  - name: nginx-demo
    image: nginx
    ports:
    - containerPort: 80
    resources:
      limits:
        memory: "4Gi"
        cpu: "2"      
      requests:
        memory: "1Gi"
        cpu: "1"
```

Lets try to deploy this Demo 2 application.
```
$ kubectl create -f demo2.yaml
Error from server (Forbidden): error when creating "demo2.yaml": pods "nginx" is forbidden: exceeded quota: mem-cpu, requested: limits.cpu=2,limits.memory=4Gi,requests.cpu=1,requests.memory=1Gi, used: limits.cpu=0,limits.memory=0,requests.cpu=0,requests.memory=0, limited: limits.cpu=1,limits.memory=1Gi,requests.cpu=500m,requests.memory=512Mi
```

This error occurs because this pod is requesting the greater resources than specified in Resource Qouta.

Once you done with this then delete the Namespace.
```
$ kubectl delete namespace quota-mem-cpu-example
namespace "quota-mem-cpu-example" deleted
```


