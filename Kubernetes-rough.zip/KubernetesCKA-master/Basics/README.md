#### Create Namespace.
```
$ kubectl create ns cloudyuga
namespace "cloudyuga" created

kubectl get ns
NAME          STATUS    AGE
cloudyuga     Active    19s
default       Active    2h
kube-public   Active    2h
kube-system   Active    2h
```
#### Running a Pod using Deployment 
```
$ kubectl run nginx --image=nginx --replicas=2 
deployment "nginx" created

$ kubectl get deploy 
NAME      DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
nginx     2         2         2            2           36s

$ kubectl get pods 
NAME                     READY     STATUS    RESTARTS   AGE
nginx-4217019353-sdwvl   1/1       Running   0          1m
nginx-4217019353-z1b15   1/1       Running   0          1m

```
#### Create a service and expose via NodePort 
```
$ kubectl expose deploy nginx --port=80 --target-port=80 --type=NodePort
service "nginx" exposed

$ kubectl get svc
NAME         CLUSTER-IP   EXTERNAL-IP   PORT(S)        AGE
kubernetes   10.0.0.1     <none>        443/TCP        3h
nginx        10.0.0.35    <nodes>       80:30613/TCP   25s

$ minikube ip
192.168.99.100

$ curl 192.168.99.100:30613
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
<style>
    body {
        width: 35em;
        margin: 0 auto;
        font-family: Tahoma, Verdana, Arial, sans-serif;
    }
</style>
</head>
<body>
<h1>Welcome to nginx!</h1>
<p>If you see this page, the nginx web server is successfully installed and
working. Further configuration is required.</p>

<p>For online documentation and support please refer to
<a href="http://nginx.org/">nginx.org</a>.<br/>
Commercial support is available at
<a href="http://nginx.com/">nginx.com</a>.</p>

<p><em>Thank you for using nginx.</em></p>
</body>
</html>

```
