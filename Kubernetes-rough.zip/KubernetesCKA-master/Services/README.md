#### Create a pod from yaml.
```
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  labels:
     app: nginx
spec:
  containers:
  - name: nginx-demo
    image: nginx:1.9.1
    ports:
    - containerPort: 80
```
#### Deploy this nginx pod.
```
$ kubectl create -f nginx-pod.yaml
pod "nginx" created
```
## Headless service.

#### Create a Headless service.
```
apiVersion: v1
kind: Service
metadata:
  name: nginx-headless
  labels:
    app: nginx
spec:
  clusterIP: None
  ports:
    - port: 80
      targetPort: 80
      protocol: TCP
  selector:
    app: nginx
```
#### Deploy the Headless Service.
```
$ kubectl create -f headless.yaml 
service "nginx-headless" created
```
#### Check the list of service.
```
$ kubectl get svc
NAME             CLUSTER-IP   EXTERNAL-IP   PORT(S)   AGE
kubernetes       10.0.0.1     <none>        443/TCP   1h
nginx-headless   None         <none>        80/TCP    58s

```
## Node Port.
#### Create a Nodeport service by using following yaml file. This service will expose the above created `nginx` pod to the the port of node. With this port and and master-IP we can access our application from outside of cluster
```
apiVersion: v1
kind: Service
metadata:
  name: nginx-nodesvc
  labels:
    app: nginx
spec:
  type: NodePort
  ports:
  - port: 80
    nodePort: 31009
    protocol: TCP
  selector:
    app: nginx
```
#### Deploy Nodeport service.
```
$ kubectl create -f nodeport.yaml 
service "nginx-nodesvc" created
```
#### Get the information of of the services present and their ports.
```
$ kubectl get svc
kubectl get svc
NAME             CLUSTER-IP   EXTERNAL-IP   PORT(S)        AGE
kubernetes       10.0.0.1     <none>        443/TCP        1h
nginx-nodesvc    10.0.0.55    <nodes>       80:31009/TCP   1m
```
Above created nginx is exposed at 31009 Nodeport by this nginx-nodesvc. So with the Minikube IP and this port we can aceess the Application from outside world.
#### Get minikube IP

```
$ minikube ip
192.168.99.100
```

#### Acccess the nginx pod via Nodeport and Minikube IP.
```
$ curl http://192.168.99.100:31009/

<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
<style>
    body {
        width: 35em;
        margin: 0 auto;
        font-family: Tahoma, Verdana, Arial, sans-serif;
    }
</style>
</head>
<body>
<h1>Welcome to nginx!</h1>
<p>If you see this page, the nginx web server is successfully installed and
working. Further configuration is required.</p>

<p>For online documentation and support please refer to
<a href="http://nginx.org/">nginx.org</a>.<br/>
Commercial support is available at
<a href="http://nginx.com/">nginx.com</a>.</p>

<p><em>Thank you for using nginx.</em></p>
</body>
</html>

```
## Load Balancer

#### Create following yaml for Load Balancer.
```
apiVersion: v1
kind: Service
metadata:
  name: nginx-lb
  labels:
    app: nginx
spec:
  type: LoadBalancer
  ports:
  - port: 80
    targetPort: 80
    protocol: TCP
  selector:
    app: nginx

```
#### deploy Loadbalancer from above yaml.
```
$ kubectl create -f loadbalancer.yaml 
service "nginx-lb" created

kubectl get svc
NAME         CLUSTER-IP   EXTERNAL-IP   PORT(S)        AGE
kubernetes   10.0.0.1     <none>        443/TCP        2h
nginx-lb     10.0.0.216   <pending>     80:31646/TCP   1m

```
## Verify the DNS service via nslookup


#### Create a `clusterIP` service of above created pod.

```
apiVersion: v1
kind: Service
metadata:
  name: nginx-svc
  labels:
    app: nginx
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 80
    protocol: TCP
  selector:
    app: nginx
```
#### Deploy above service.
```
$ Kubectl nginx-svc.yaml
service "nginx-svc" created

$ kubectl get svc
NAME         CLUSTER-IP   EXTERNAL-IP   PORT(S)   AGE
kubernetes   10.0.0.1     <none>        443/TCP   1h
nginx-svc    10.0.0.134   <none>        80/TCP    8s

```
#### Run another deployement nginx n check the dnslookup by service name.
```
$ kubectl run nginxdemo -it --rm --image=nginx:1.9.1 /bin/sh
#
# apt update
# apt-get install dnsutils
#  nslookup nginx-svc
Server:		10.0.0.10
Address:	10.0.0.10#53

Name:	nginx-svc.default.svc.cluster.local
Address: 10.0.0.134
```
 Within the same namespace service can be accessed by the other service/pods with its DNS name. 
